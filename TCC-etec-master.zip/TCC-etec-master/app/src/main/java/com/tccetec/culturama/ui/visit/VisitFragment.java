package com.tccetec.culturama.ui.visit;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tccetec.culturama.R;
import com.tccetec.culturama.ui.events.AdapterEvent;
import com.tccetec.culturama.ui.events.Event;

import java.util.ArrayList;
import java.util.List;

public class VisitFragment extends Fragment {


    private Visit[] Visita = {new Visit("MUSEU","Vei ser loko","01/02/333",R.drawable.splash_fundo), new Visit("EventoY","evento epico, melhor que a BGS", "20/12/2020",R.drawable.welcomeimage)};



    private RecyclerView recyclerview;
    private List<Visit> visits = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_visit, container, false);
        recyclerview = view.findViewById(R.id.recyclerView2);
        initView();
        return view;
    }

    private void initView() {
        GridLayoutManager layoutManager = new GridLayoutManager(this.getContext(), 1);//Parameter: context, number of columns
        recyclerview.setLayoutManager(layoutManager);
        AdapterVisit adapter = new AdapterVisit(visits);
        recyclerview.setAdapter(adapter);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVisit();
    }

    private void initVisit() {
        visits.clear();
        for (int i = 0; i < Visita.length; i++) {

            visits.add(Visita[i]);
        }

    }
}