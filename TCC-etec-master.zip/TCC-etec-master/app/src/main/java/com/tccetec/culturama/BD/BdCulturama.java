package com.tccetec.culturama.BD;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.tccetec.culturama.ui.usuarios.Usuarios;

import static java.sql.Types.BOOLEAN;
import static java.util.Calendar.DATE;

public class BdCulturama extends SQLiteOpenHelper {

    public static final int VERSION = 1;
    public static final String NOME_DB = "db_culturama";
    //tabelas:
    public static String tab_evento = "tb_evento";
    public static String tab_visit = "tb_local_fixo";
    public static  String tab_user = "tb_usuario";

    //colunas tablela user
    public static  String id = "id";
    public static  String nome_usuario = "nome_usuario";
    public static  String senha_usuario = "senha_usuario";
    public static  String email_usuario = "email_usuario";
    public static  String telefone_usuario = "telefone_usuario";
    public static  String dataNasc_usuario = "dataNasc_usuario";
    public static  String aceito_termos = "aceito_termos";
    public static  String categorias_preferencias = "categorias_preferencias";

    //colunas da tabela event

    public static  String id_event = "id";
    public static  String nome_evento = "nome_evento";
    public static  String descricao_evento = "descricao_evento";
    public static  String data_evento = "data_evento";
    public static  String horario_entrada = "horario_entrada";
    public static  String horario_saida = "horario_saida";
    public static  String id_organizador = "id_organizador";
    public static  String num_endereco = "num_endereco";
    public static  String preco_evento = "preco_evento";
    public static  String link_evento = "link_evento";
    public static  String cat_evento = "cat_evento";
    public static  String imagem_evento= "imagem_evento";


    public static  String tab_avaliaçao = "tb_avaliacao";
    public static  String tab_endereço = "tb_endereco";
    public static  String tb_endereco_usuario = "tb_endereco_usuario";
    public static  String tb_interesses = "tb_interesses";
    public static  String tb_organizador = "tb_organizador";
    public static  String tb_pf = "tb_pf";
    public static  String tb_pj = "tb_pj";
    public static  String tb_setor_evento = "tb_setor_evento";




    public BdCulturama(@Nullable Context context) {
        super(context, NOME_DB, null, VERSION);
    }

//    @Override
//    public void onOpen(SQLiteDatabase db) {
//        super.onOpen(db);
//        if(!db.isReadOnly()){
//            db.execSQL("Pragma foreign_keys=ON;");
//        }
//    }

    @Override
    public void onCreate(SQLiteDatabase db) {

//        db.execSQL("CREATE TABLE " + tab_avaliaçao + "(" +
//                "  id_usuario int(11) NOT NULL," +
//                "  id_organizador int(11) NOT NULL," +
//                "  valor_avaliacao int(11) NOT NULL,"+
//                " Constraint  FK_avaliador FOREIGN KEY (id_usuario) References tb_usuario(id_usuario)," +
//                "Constraint  FK_avaliado FOREIGN KEY (id_organizador) References tb_organizador(id_organizador))");
//
//        db.execSQL("CREATE TABLE "+ tab_endereço +
//                  " (id_endereco int(11) PRIMARY KEY  AUTOINCREMENT NOT NULL," +
//                "  rua_endereco varchar(255) NOT NULL," +
//                "  bairro_endereco varchar(255) NOT NULL," +
//                "  cidade_endereco varchar(255) NOT NULL," +
//                "  uf_endereco char(2) NOT NULL," +
//                "  cep_endereco char(8) NOT NULL," +
//                "  complemento_endereco varchar(255) DEFAULT NULL" +
//                ")");
//
//        db.execSQL("CREATE TABLE "+tb_endereco_usuario+" (" +
//                "  id_usuario int(11) NOT NULL," +
//                "  id_endereco int(11) NOT NULL," +
//                "  numero_endereco int(11) NOT NULL," +
//                " Constraint  FK_usuario_endereco FOREIGN KEY (id_usuario) References tb_usuario(id_usuario)," +
//                "Constraint  FK_endereco_usuario FOREIGN KEY (id_endereco) References tb_endereco(id_endereco))");
//
//
//
//        db.execSQL("CREATE TABLE "+tb_interesses+" " +
//                " ( data_interesse date DEFAULT NULL," +
//                "  id_usuario int(11) DEFAULT NULL," +
//                "  id_evento int(11) DEFAULT NULL," +
//                " Constraint  FK_usuario_interessado FOREIGN KEY (id_usuario) References tb_usuario(id_usuario)," +
//             "Constraint  FK_evento_interesse FOREIGN KEY (id_evento) References tb_evento(id_evento))");
//
//
//
//        db.execSQL("CREATE TABLE "+tb_organizador+" (" +
//                "  id_organizador int(11) PRIMARY KEY AUTOINCREMENT," +
//                "  nome_organizador varchar(255) NOT NULL," +
//                "  email_organizador varchar(255) NOT NULL" +
//                ")" );
//
//
//        db.execSQL("CREATE TABLE "+tb_pf+" (" +
//                "  cpf_pg char(11) NOT NULL," +
//                "  id_organizador int(11) DEFAULT NULL," +
//                " Constraint  FK_cpf_organizador FOREIGN KEY (id_organizador) References tb_organizador(id_organizador))");
//
        db.execSQL( "CREATE TABLE " + tab_evento
                     + "("+ id_event +" Integer PRIMARY KEY AUTOINCREMENT," +
                          ""+nome_evento+" varchar(255) NOT NULL,"+
                          ""+descricao_evento+" LONGTEXT NOT NULL,"+
                          ""+data_evento+" DATE NOT NULL,"+
                          ""+horario_entrada+" time DEFAULT NULL," +
                            ""+horario_saida+" time DEFAULT NULL,"+
                            ""+id_organizador+" int(11) NOT NULL,"+
                           // "id_endereco int(11) NOT NULL,"+
                            ""+num_endereco+" varchar(255) NOT NULL," + //mudei pra varchar
                           // "tags_evento varchar(255) DEFAULT NULL,"+
                            ""+preco_evento+" varchar(255) DEFAULT NULL,"+ //novo
                            ""+link_evento+" varchar(255) DEFAULT NULL,"+ //novo
                            ""+cat_evento+" varchar(255) DEFAULT NULL,"+ //novo
                            ""+imagem_evento+" BLOB DEFAULT NULL)");
                            /*"tipo_imagem varchar(25) NOT NULL)");*/


//        db.execSQL("CREATE TABLE "+tb_pj+" (" +
//                "  cnpj_pj char(11) NOT NULL," +
//                "  id_organizador int(11) DEFAULT NULL" +
//                ")");
//
//        db.execSQL( "CREATE TABLE " + tab_visit
//                            + "(id_local int(11) PRIMARY KEY NOT NULL ," +
//                            "nome_local varchar(255) NOT NULL,"+
//                            "email_local varchar(255) NOT NULL,"+
//                            "descricao_local LONGTEXT NOT NULL,"+
//                            "telefone_local varchar(15) NOT NULL," +
//                            "funcionamento_local varchar(255) NOT NULL,"+
//                            "tags_local varchar(255) NOT NULL,"+
//                            "id_endereco int(11) NOT NULL,"+
//                            "id_endereco int NOT NULL," +
//                            "id_organizador int not NULL,"+
//                            " Constraint  FK_organizador_local FOREIGN KEY (id_organizador) References tb_organizador(id_organizador)," +
//                            "Constraint  FK_endereco_local FOREIGN KEY (id_endereco) References tb_endereco(id_endereco))");


        db.execSQL( "CREATE TABLE " + tab_user
                            + "("+id +" integer primary key autoincrement," +
                            ""+nome_usuario+" varchar(255) ,"+
                            ""+senha_usuario+" varchar(255) ,"+
                            ""+email_usuario+" varchar(255) ,"+
                            ""+telefone_usuario+" varchar(15) ," +
                            ""+dataNasc_usuario+" DATE, " +
                            ""+aceito_termos+" BOOLEAN, " + //novos
                             ""+categorias_preferencias+" varchar(255)) "); //novos

//        db.execSQL("CREATE TABLE "+tb_setor_evento+" (" +
//                "  id_setor int(11) PRIMARY KEY AUTOINCREMENT," +
//                "  nome_setor varchar(255) NOT NULL," +
//                "  id_evento int(11) DEFAULT NULL," +
//                " Constraint  FK_setor_evento FOREIGN KEY (id_evento) References tb_evento(id_evento))");




    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


//    void selectPessoa(String email , String senha){
//        SQLiteDatabase db = this.getReadableDatabase();
//
//        Cursor c = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE email_usuario = ?", new String[]{email});
//
//        if(c != null){
//            c.moveToFirst();
//        }
//
//        Usuarios usuarios;
//        usuarios = new Usuarios(Integer.parseInt(c.getInt(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),Boolean.parseBoolean(c.getWantsAllOnMoveCalls(6)));
//    }


}
