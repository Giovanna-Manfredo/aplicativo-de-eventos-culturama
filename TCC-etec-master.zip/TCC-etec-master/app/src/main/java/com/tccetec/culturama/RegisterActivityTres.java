package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.util.ArrayList;

public class RegisterActivityTres extends AppCompatActivity {
    private CulturamaDAO dao;
    private CheckBox termos;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_tres);
        termos = findViewById(R.id.Termos);

        dao = new CulturamaDAO(this);
        if (termos.isChecked()) {

            Bundle bd = new Bundle();
            bd.putBoolean("termos", true);
        }




    }
    public void registrar(View view){


            Bundle extras = getIntent().getExtras();
            String nomePessoa = extras.getString("nome");
            String senha = extras.getString("senha");
            String email = extras.getString("email");
            String phone = extras.getString("phone");
            String dataNasc = extras.getString("dataNasc");
            String[] categorias = extras.getStringArray("categorias");

        Usuarios u = new Usuarios();
        u.setNome(nomePessoa);
        u.setSenha(senha);
        u.setEmail(email);
        u.setTelefone(phone);
        u.setDataNasc(dataNasc);
        u.setCategorias(categorias);


        try {




     long id = dao.inserir(u);
     Toast.makeText(this, "registro " + id, Toast.LENGTH_SHORT).show();

            startActivity(new Intent(getBaseContext(), LoginActivity.class));

        }catch (Exception e){
            Toast.makeText(this, "erro" + e, Toast.LENGTH_SHORT).show();
        }

    }
}