package com.tccetec.culturama.ui.events;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class EventsFragment extends Fragment {

 
    private Event[] Evento = {new Event(1,"Nome do evento","Vei ser loko","01/02/333",null, null, 0,null,null,null, null,null)};


    private RecyclerView myrecyclerview;
    private List<Event> eventos = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment



        View view = inflater.inflate(R.layout.fragment_events, container, false);
        myrecyclerview = view.findViewById(R.id.recycler);
        initView();
       return view;
    }

    private void initView() {
        GridLayoutManager layoutManager = new GridLayoutManager(this.getContext(), 1);//Parameter: context, number of columns
        myrecyclerview.setLayoutManager(layoutManager);
        AdapterEvent adapter = new AdapterEvent(eventos);
        myrecyclerview.setAdapter(adapter);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initEvents();
    }

    private void initEvents() {
        eventos.clear();
        for (int i = 0; i < Evento.length; i++) {

            eventos.add(Evento[i]);
        }
    }

    public void event(View view){

    }

    public void visit(View view){

    }

}