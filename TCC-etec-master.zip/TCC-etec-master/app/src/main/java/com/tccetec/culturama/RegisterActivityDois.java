package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RegisterActivityDois extends AppCompatActivity {

    CheckBox cat1, cat2, cat3, cat4, cat5, cat6;
    List<String> check = new ArrayList<String>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_dois);

        cat1 = findViewById(R.id.cat1);
        cat2 = findViewById(R.id.cat2);
        cat3 = findViewById(R.id.cat3);
        cat4 = findViewById(R.id.cat4);
        cat5 = findViewById(R.id.cat5);
        cat6 = findViewById(R.id.cat6);

        Button go = findViewById(R.id.btnProx);

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Toast para testar se o dados estao paassando
                Intent dadosRecebidos = getIntent();
                Bundle extras = dadosRecebidos.getExtras();
                String nomePessoa = extras.getString("nome");
                String senha = extras.getString("senha");
                String email = extras.getString("email");
                String phone = extras.getString("phone");
                String dataNasc = extras.getString("dataNasc");


                check.clear();
                if(cat1.isChecked()){
                    check.add(cat1.getText().toString());



                }
                if(cat2.isChecked()){
                    check.add(cat2.getText().toString());

                }
                if(cat3.isChecked()){
                    check.add(cat3.getText().toString());

                }
                if(cat4.isChecked()){
                    check.add(cat4.getText().toString());

                }
                if(cat5.isChecked()){
                    check.add(cat5.getText().toString());

                }
                if(cat6.isChecked()){
                    check.add(cat6.getText().toString());

                }
                Intent i = new Intent(getBaseContext(),RegisterActivityTres.class);
                Bundle bd = new Bundle();
                bd.putStringArray("categorias", new String[]{String.valueOf(check)});
                bd.putString("nome", nomePessoa);
                bd.putString("senha",  senha);
                bd.putString("email", email);
                bd.putString("phone",  phone);
                bd.putString("dataNasc", dataNasc);
                i.putExtras(bd);
                startActivity(i);
                  }




        });
    }


}