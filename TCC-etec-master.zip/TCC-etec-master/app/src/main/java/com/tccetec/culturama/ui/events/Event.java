package com.tccetec.culturama.ui.events;

import android.graphics.Bitmap;

import java.io.Serializable;

public class Event implements Serializable {
    private Integer id;
    private  String nome_evento;
    private  String descricao_evento ;
    private  String data_evento ;
    private  String horario_entrada;
    private  String horario_saida ;
    private  int id_organizador ;
    private  String num_endereco ;
    private  String preco_evento ;
    private  String link_evento ;
    private  String cat_evento ;
    private Bitmap imagem_evento;

    public Event() {
    }

    public Event(Integer id, String nome_evento, String descricao_evento, String data_evento, String horario_entrada, String horario_saida, int id_organizador, String num_endereco, String preco_evento, String link_evento, String cat_evento, Bitmap imagem_evento) {
        this.id = id;
        this.nome_evento = nome_evento;
        this.descricao_evento = descricao_evento;
        this.data_evento = data_evento;
        this.horario_entrada = horario_entrada;
        this.horario_saida = horario_saida;
        this.id_organizador = id_organizador;
        this.num_endereco = num_endereco;
        this.preco_evento = preco_evento;
        this.link_evento = link_evento;
        this.cat_evento = cat_evento;
        this.imagem_evento = imagem_evento;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome_evento() {
        return nome_evento;
    }

    public void setNome_evento(String nome_evento) {
        this.nome_evento = nome_evento;
    }

    public String getDescricao_evento() {
        return descricao_evento;
    }

    public void setDescricao_evento(String descricao_evento) {
        this.descricao_evento = descricao_evento;
    }

    public String getData_evento() {
        return data_evento;
    }

    public void setData_evento(String data_evento) {
        this.data_evento = data_evento;
    }

    public String getHorario_entrada() {
        return horario_entrada;
    }

    public void setHorario_entrada(String horario_entrada) {
        this.horario_entrada = horario_entrada;
    }

    public String getHorario_saida() {
        return horario_saida;
    }

    public void setHorario_saida(String horario_saida) {
        this.horario_saida = horario_saida;
    }

    public int getId_organizador() {
        return id_organizador;
    }

    public void setId_organizador(int id_organizador) {
        this.id_organizador = id_organizador;
    }

    public String getNum_endereco() {
        return num_endereco;
    }

    public void setNum_endereco(String num_endereco) {
        this.num_endereco = num_endereco;
    }

    public String getPreco_evento() {
        return preco_evento;
    }

    public void setPreco_evento(String preco_evento) {
        this.preco_evento = preco_evento;
    }

    public String getLink_evento() {
        return link_evento;
    }

    public void setLink_evento(String link_evento) {
        this.link_evento = link_evento;
    }

    public String getCat_evento() {
        return cat_evento;
    }

    public void setCat_evento(String cat_evento) {
        this.cat_evento = cat_evento;
    }

    public Bitmap getImagem_evento() {
        return imagem_evento;
    }

    public void setImagem_evento(Bitmap imagem_evento) {
        this.imagem_evento = imagem_evento;
    }
}
