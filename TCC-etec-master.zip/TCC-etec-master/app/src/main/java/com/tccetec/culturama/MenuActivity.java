package com.tccetec.culturama;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.DatabaseErrorHandler;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.util.Arrays;
import java.util.List;

import static androidx.navigation.Navigation.findNavController;
import static com.tccetec.culturama.R.mipmap.ic_launcher;

public class MenuActivity extends AppCompatActivity {
    CulturamaDAO dao;
    String nome;
    int idOrg;
    Button btnChoose;
    ImageView imageEvent;
    private static final int REQUEST_CODE_GALLERY = 100;
    private Uri imageFilePath;
    private Bitmap imageToStore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        final Button btEvent = findViewById(R.id.buttonEvent);
        final Button btVisit = findViewById(R.id.buttonVisit);
        final SearchView searchView = findViewById(R.id.search);
        final ImageView imageBarra = findViewById(R.id.barraContainer);
         final String nomeUser;









            SharedPreferences sp = getApplication().getSharedPreferences("ArquivoPreferencia", Context.MODE_PRIVATE);
             nome = sp.getString("nome","nao ");
             idOrg = sp.getInt("id",0);



        dao = new CulturamaDAO(this);


        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView2);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, new MenuEventVisitFragment()).commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectFragment = null;
                switch (item.getItemId()) {

                    case R.id.nav_evenvisit:
                        selectFragment = new MenuEventVisitFragment();
                        final TextView text = findViewById(R.id.textNomeProfile);

                        break;
                    case R.id.nav_addEvent:
                        selectFragment = new addEventFragment();

                        break;
                    case R.id.nav_profile:
                        selectFragment = new PerfilFragment();



                        break;
                    case R.id.nav_notification:
                        selectFragment = new NotificationFragment();

                        break;

                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, selectFragment).commit();

                return true;
            }
        });
    }

    public void profile(){
        Intent intent = new Intent( getBaseContext() , EditProfileActivity.class);
        getBaseContext().startActivity(intent);
    }
    public void onFragmentViewCreated(View view) {
        // Iniciar os campos buscando no layout do Fragment
        TextView nomePerfil = (TextView) view.findViewById(R.id.textNomeProfile);
        nomePerfil.setText(nome);


        }
public void registerEvent(View view){



   SharedPreferences preferenc = getSharedPreferences("pre", Context.MODE_PRIVATE);
    String nameEvent = preferenc.getString("nameEvent","nao");
    String precoEvent = preferenc.getString("precoEvent","nao");
    String enderEvet = preferenc.getString("enderEvet","nao");
    String descriEvent = preferenc.getString("descriEvent","nao");
    String saidaEvent = preferenc.getString("saidaEvent","nao");
    String entraEvent = preferenc.getString("entraEvent","nao");
    String dataEvent = preferenc.getString("dataEvent","nao");
    String catEvent = preferenc.getString("catEvent","nao");
    String linkEvent = preferenc.getString("linkEvent","nao");


    Event e = new Event();
    e.setNome_evento(nameEvent);
    e.setPreco_evento(precoEvent);
    e.setNum_endereco(enderEvet);
    e.setDescricao_evento(descriEvent);
    e.setHorario_saida(saidaEvent);
    e.setHorario_entrada(entraEvent);
    e.setData_evento(dataEvent);
    e.setCat_evento(catEvent);
    e.setLink_evento(linkEvent);
    e.setId_organizador(idOrg);
    e.setImagem_evento(imageToStore);



    try {


        long id_event = dao.inserirEvent(e);
        Toast.makeText(this, "registro " + " " + id_event, Toast.LENGTH_SHORT).show();


    }catch (Exception er){
        Toast.makeText(this, "erro" + er, Toast.LENGTH_SHORT).show();
    }
}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try{
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data.getData() != null) {

            imageFilePath = data.getData();
            imageToStore = MediaStore.Images.Media.getBitmap(this.getContentResolver(),imageFilePath);

            imageEvent.setImageBitmap(imageToStore);

        }

            }catch (Exception e){
                e.printStackTrace();
            }
        }


    public void choose(View view){
        Intent i = new Intent();
        i.setType("image/*");

        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(i,REQUEST_CODE_GALLERY);

    }

    public void onFragmentViewCreated2(View view) {
        imageEvent = view.findViewById(R.id.imageViewEvent);


    }
}


//
//











