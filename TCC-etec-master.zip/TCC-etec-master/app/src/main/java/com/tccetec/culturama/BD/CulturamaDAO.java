package com.tccetec.culturama.BD;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.widget.Toast;

import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.io.ByteArrayOutputStream;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Arrays;

public class CulturamaDAO {
    private BdCulturama conexao;
    private SQLiteDatabase banco;
    private ByteArrayOutputStream objectByteArrayOutPutScream;
    private byte[] ImageInBytes;

    public CulturamaDAO(Context context) {
        try {
            conexao = new BdCulturama(context);
            banco = conexao.getWritableDatabase();
        } catch (Exception e) {
            Toast.makeText(context, "erro no bd:" + e, Toast.LENGTH_SHORT).show();
        }

    }

    public long inserirEvent(Event event) {
        Bitmap imageToStoreBipmap = event.getImagem_evento();
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        imageToStoreBipmap.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();

        ContentValues value = new ContentValues();
        value.put("nome_evento", event.getNome_evento());
        value.put("preco_evento", event.getPreco_evento());
        value.put("descricao_evento", event.getDescricao_evento());
        value.put("link_evento", event.getLink_evento());
        value.put("cat_evento", event.getCat_evento());
        value.put("horario_entrada", event.getHorario_entrada());
        value.put("horario_saida", event.getHorario_saida());
        value.put("imagem_evento", ImageInBytes);
        value.put("id_organizador", event.getId_organizador());
        value.put("num_endereco", event.getNum_endereco());
        value.put("data_evento", event.getData_evento());
        return banco.insert(BdCulturama.tab_evento, null, value);

    }

    public long inserir(Usuarios usuarios) {
        ContentValues values = new ContentValues();
        values.put("nome_usuario", usuarios.getNome());
        values.put("senha_usuario", usuarios.getSenha());
        values.put("email_usuario", usuarios.getEmail());
        values.put("telefone_usuario", usuarios.getTelefone());
        values.put("dataNasc_usuario", usuarios.getDataNasc());
        values.put("aceito_termos", usuarios.getTermos());
        values.put("categorias_preferencias", Arrays.toString(usuarios.getCategorias()));
        return banco.insert(BdCulturama.tab_user, null, values);

    }

    public Usuarios selectUsuario(String email, String senha) {

        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE " + BdCulturama.email_usuario + " = ? AND " + BdCulturama.senha_usuario + " = ?", new String[]{email, senha});

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Usuarios usuario = new Usuarios(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), Boolean.parseBoolean(cursor.getString(6)), new String[]{cursor.getString(7)});

        return usuario;
    }



    public ArrayList<Event> listarEvents (){
        ArrayList<Event> eventos = new ArrayList <> () ;
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_evento ,null);

        if (cursor.moveToFirst ()) {
            do {
                Event newEvent = new Event () ;
                newEvent.setId (cursor.getInt (0));
                newEvent.setNome_evento (cursor.getString (1));
                newEvent.setDescricao_evento (cursor.getString (2));
                newEvent.setData_evento (cursor.getString (3));
                newEvent.setHorario_entrada (cursor.getString (4));
                newEvent.setHorario_saida (cursor.getString (5));
                newEvent.setId_organizador (cursor.getInt (6));
                newEvent.setNum_endereco (cursor.getString (7));
                newEvent.setPreco_evento (cursor.getString (8));
                newEvent.setLink_evento (cursor.getString (9));
                newEvent.setCat_evento (cursor.getString (10));
                eventos.add (newEvent) ;
            } while (cursor.moveToNext ()) ;
        }
        return eventos;
    }



        public Boolean logar(String email, String senha){
            SQLiteDatabase db = conexao.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE "+BdCulturama.email_usuario+" = ? AND "+BdCulturama.senha_usuario+" = ?", new String[]{email, senha});

            if(cursor.getCount()>0){

                return true;

            }
            return false;
        }




}
