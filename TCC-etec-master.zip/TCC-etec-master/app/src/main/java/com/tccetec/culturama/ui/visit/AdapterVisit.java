package com.tccetec.culturama.ui.visit;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.tccetec.culturama.R;
import com.tccetec.culturama.VisitActivity;

import java.util.List;

public class AdapterVisit extends RecyclerView.Adapter<AdapterVisit.MyViewHolder> {
    Context context;
    List<Visit> visitList;

    public AdapterVisit(List<Visit> visitList) {
        this.visitList = visitList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (context == null) {
            context = parent.getContext();
        }

        View view = LayoutInflater.from(context).inflate(R.layout.layout_visit, parent, false);
        return new AdapterVisit.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.nameVisit.setText(visitList.get(position).getNomeVisit());
        holder.DescVisit.setText(visitList.get(position).getDescVisit());
        holder.DataVisit.setText(visitList.get(position).getDataVisit());
        holder.imageVisit.setImageResource(visitList.get(position).getImagemVisit());

        holder.CardVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(context, VisitActivity.class);

                intent.putExtra("nameVisit", visitList.get(position).getNomeVisit());

                v.getContext().startActivity(intent);


            }
        });

    }

    @Override
    public int getItemCount() {
        return visitList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{

        private ImageView imageVisit;
        private TextView nameVisit;
        private TextView DescVisit;
        private TextView DataVisit;
        private CardView CardVisit;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageVisit = itemView.findViewById(R.id.imageVisit);
            nameVisit = itemView.findViewById(R.id.nameVisit);
            DescVisit = itemView.findViewById(R.id.DescVisit);
            DataVisit = itemView.findViewById(R.id.DataVisit);
            CardVisit = itemView.findViewById(R.id.cardVisit);

        }
        }
}
