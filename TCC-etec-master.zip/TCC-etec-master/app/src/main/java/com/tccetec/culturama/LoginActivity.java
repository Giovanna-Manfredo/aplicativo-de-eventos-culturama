package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    private EditText email;
    private EditText senha;
    private Button logar;
    private CulturamaDAO dao;
    private ArrayList<Usuarios> usuario;
    private ArrayList<Usuarios> usuarioFiltrado = new ArrayList<>();
    private static String ARQUIVO_PREFERENCIA = "ArquivoPreferencia";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dao = new CulturamaDAO(getBaseContext());
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
        logar = findViewById(R.id.Logar);


        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailLog = email.getText().toString();
                String senhaLog = senha.getText().toString();
                try {

                  Boolean user = dao.logar(emailLog, senhaLog);

                   if(user == true){

                        Usuarios userInfo = new Usuarios();
                        userInfo = dao.selectUsuario(emailLog, senhaLog);
                       SharedPreferences preferences = getSharedPreferences(ARQUIVO_PREFERENCIA, 0);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putInt("id",userInfo.getId());
                        editor.putString("nome", userInfo.getNome());
                        editor.putString("senha", userInfo.getSenha());
                        editor.putString("email", userInfo.getEmail());
                        editor.putString("telefone", userInfo.getTelefone());
                        editor.putString("dataNasc", userInfo.getDataNasc());
                        editor.commit();

                        Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                        startActivity(intent);
                   }else{
                       Toast.makeText(LoginActivity.this, "nao existe" , Toast.LENGTH_SHORT).show();
                   }



                }catch (Exception e){
                    Toast.makeText(LoginActivity.this, "Erro ao se logar" + e, Toast.LENGTH_SHORT).show();
                }


                }
        });








    }




}