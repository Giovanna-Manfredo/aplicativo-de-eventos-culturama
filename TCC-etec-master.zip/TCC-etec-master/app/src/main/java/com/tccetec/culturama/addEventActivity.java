package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.tccetec.culturama.R;

public class addEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
    }
}