package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class VisitActivity extends AppCompatActivity {
    TextView textView;

    String namePut;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit);

        textView= findViewById(R.id.textViewTest);

        namePut = getIntent().getStringExtra("nameVisit");
        textView.setText(namePut);



    }
}