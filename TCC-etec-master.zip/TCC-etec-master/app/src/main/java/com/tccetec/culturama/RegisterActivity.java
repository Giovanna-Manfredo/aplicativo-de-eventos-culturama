package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.io.Serializable;

public class RegisterActivity extends AppCompatActivity {
    private EditText nome;
    private EditText senha;
    private EditText email;
    private EditText telefone;
    private EditText dataNasc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        nome = findViewById(R.id.editNome);
        senha = findViewById(R.id.editSenha);
        email = findViewById(R.id.editEmailLogin);
        telefone = findViewById(R.id.editPhone);
        dataNasc = findViewById(R.id.editDate);

    // dao = new CulturamaDAO(getBaseContext());
        Button go = findViewById(R.id.btnProx);

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),RegisterActivityDois.class);
                Bundle bd = new Bundle();
                bd.putString("nome", nome.getText().toString());
                bd.putString("senha",  senha.getText().toString());
                bd.putString("email", email.getText().toString());
                bd.putString("phone",  telefone.getText().toString());
                bd.putString("dataNasc", dataNasc.getText().toString());
                i.putExtras(bd);
                startActivity(i);
            }
        });

    }



}