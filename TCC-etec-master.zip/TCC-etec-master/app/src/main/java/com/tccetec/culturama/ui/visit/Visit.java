package com.tccetec.culturama.ui.visit;

public class Visit {
    private String nomeVisit;
    private String descVisit;
    private String dataVisit;
    private int imagemVisit;

    public Visit() {
    }

    public Visit(String nomeVisit, String descVisit, String dataVisit, int imagemVisit) {
        this.nomeVisit = nomeVisit;
        this.descVisit = descVisit;
        this.dataVisit = dataVisit;
        this.imagemVisit = imagemVisit;
    }

    public String getNomeVisit() {
        return nomeVisit;
    }

    public void setNomeVisit(String nomeVisit) {
        this.nomeVisit = nomeVisit;
    }

    public String getDescVisit() {
        return descVisit;
    }

    public void setDescVisit(String descVisit) {
        this.descVisit = descVisit;
    }

    public String getDataVisit() {
        return dataVisit;
    }

    public void setDataVisit(String dataVisit) {
        this.dataVisit = dataVisit;
    }

    public int getImagemVisit() {
        return imagemVisit;
    }

    public void setImagemVisit(int imagemVisit) {
        this.imagemVisit = imagemVisit;
    }
}
