package com.tccetec.culturama;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.ModelItem;
import com.tccetec.culturama.ui.events.AdapterEvent;
import com.tccetec.culturama.ui.events.AdapterMyEvent;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;
import com.tccetec.culturama.ui.visit.AdapterMyVisit;
import com.tccetec.culturama.ui.visit.AdapterVisit;
import com.tccetec.culturama.ui.visit.Visit;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static androidx.navigation.Navigation.findNavController;

public class MenuActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    AdaptSearch adapter;

    ListView listView;
 Toolbar  toolbar;
    ArrayList<ModelItem> ar = new ArrayList<>();

    CulturamaDAO dao;
    String nome;
    int idOrg;
    Button btnChoose;
    ImageView imageEvent;

   private List<ModelItem> exampleList = new ArrayList<>();


    private static final int REQUEST_CODE_GALLERY = 100;
    private Uri imageFilePath;
    private Bitmap imageToStore;
    Bitmap fotoUser;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        final Button btEvent = findViewById(R.id.buttonEvent);
        final Button btVisit = findViewById(R.id.buttonVisit);

         final String nomeUser;

         getSupportActionBar().setElevation(0);

        SharedPreferences sp = getApplication().getSharedPreferences("ArquivoPreferencia", Context.MODE_PRIVATE);
             idOrg = sp.getInt("id",0);


        dao = new CulturamaDAO(this);
        Usuarios tal = dao.selectId(idOrg);
        nome = tal.getNome();

        ar = dao.getModel();
        adapter = new AdaptSearch(this,ar);



        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView2);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, new MenuEventVisitFragment()).commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectFragment = null;
                switch (item.getItemId()) {

                    case R.id.nav_evenvisit:
                        selectFragment = new MenuEventVisitFragment();
                        final TextView text = findViewById(R.id.textNomeProfile);
                        getSupportActionBar().show();


                        break;
                    case R.id.nav_addEvent:
                        selectFragment = new addFragment();
                        getSupportActionBar().hide();
                        break;
                    case R.id.nav_profile:
                        selectFragment = new PerfilFragment();
                        getSupportActionBar().hide();


                        break;
                    case R.id.nav_notification:
                        selectFragment = new NotificationFragment();
                        getSupportActionBar().hide();
                        break;

                }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, selectFragment).commit();

                return true;
            }
        });
    }







    public void profile(){

      this.finish();
        Intent intent = new Intent( getBaseContext() , EditProfileActivity.class);

        getBaseContext().startActivity(intent);

    }
    public void onFragmentViewCreated(View view) {
        // Iniciar os campos buscando no layout do Fragment
        TextView v  = this.findViewById(R.id.textNomeProfile);
        v.setText(nome);
        try {

            fotoUser = dao.recuperaPerfil(idOrg);
        }catch (Exception e){
            Toast.makeText(this, ""+ e, Toast.LENGTH_SHORT).show();
        }


        ImageView fotoPerfil = view.findViewById(R.id.imageView);
        fotoPerfil.setImageBitmap(fotoUser);

        RecyclerView myrecyclerview = view.findViewById(R.id.RecyclerMeusEvents);
        List<Event> eventos = new ArrayList<>();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        myrecyclerview.setLayoutManager(layoutManager);
        AdapterMyEvent adapter = new AdapterMyEvent(eventos);
        myrecyclerview.setAdapter(adapter);


        eventos.clear();

        Event[] list = dao.obterMyEventos(String.valueOf(idOrg));


        if(eventos == null || eventos.isEmpty()){
            TextView tx = findViewById(R.id.text1);
            tx.setVisibility(View.GONE);
        }


            for (int i = 0; i < list.length; i++) {

                eventos.add(list[i]);
            }

            //visit


        RecyclerView myrecyclerview2 = view.findViewById(R.id.ReciclerMeusLugares);
        List<Visit> visit = new ArrayList<>();

        LinearLayoutManager layoutManager2 = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        myrecyclerview2.setLayoutManager(layoutManager2);
        AdapterMyVisit adapt = new AdapterMyVisit(visit);
        myrecyclerview2.setAdapter(adapt);

        visit.clear();

        Visit[] list2 = dao.obterMyVisit(String.valueOf(idOrg));


        for (int i = 0; i < list2.length; i++) {

            visit.add(list2[i]);
        }



        //favorit



    }

public void registerEvent(View view){


        if(imageToStore == null){
            Toast.makeText(this, "Insira uma imagem!", Toast.LENGTH_SHORT).show();
        }else {

            SharedPreferences preferenc = getSharedPreferences("pre", Context.MODE_PRIVATE);
            String nameEvent = preferenc.getString("nameEvent", "nao");
            String precoEvent = preferenc.getString("precoEvent", "nao");
            String enderEvet = preferenc.getString("enderEvet", "nao");
            String descriEvent = preferenc.getString("descriEvent", "nao");
            String saidaEvent = preferenc.getString("saidaEvent", "nao");
            String entraEvent = preferenc.getString("entraEvent", "nao");
            String dataEvent = preferenc.getString("dataEvent", "nao");
            String catEvent = preferenc.getString("catEvent", "nao");
            String linkEvent = preferenc.getString("linkEvent", "nao");


            Event e = new Event();
            e.setNome_evento(nameEvent);
            e.setPreco_evento(precoEvent);
            e.setNum_endereco(enderEvet);
            e.setDescricao_evento(descriEvent);
            e.setHorario_saida(saidaEvent);
            e.setHorario_entrada(entraEvent);
            e.setData_evento(dataEvent);
            e.setCat_evento(catEvent);
            e.setLink_evento(linkEvent);
            e.setId_organizador(idOrg);
            e.setImagem_evento(imageToStore);


            long id_event = dao.inserirEvent(e);
            startActivity(new Intent(getBaseContext(), MenuActivity.class));
            this.finish();
        }

}



    public void registerLocal(View view) {


        if (imageToStore == null) {
            Toast.makeText(this, "Insira uma imagem!", Toast.LENGTH_SHORT).show();
        } else {


            SharedPreferences preferenc = getSharedPreferences("prefVisit", Context.MODE_PRIVATE);
            String name = preferenc.getString("nomeV", "nao");
            String preco = preferenc.getString("precoV", "nao");
            String email = preferenc.getString("emailV", "nao");
            String descr = preferenc.getString("desV", "nao");
            String telefone = preferenc.getString("teleV", "nao");
            String funci = preferenc.getString("FuncV", "nao");
            String endereço = preferenc.getString("endeV", "nao");
            String linkLocal = preferenc.getString("linkV", "nao");
            String cat = preferenc.getString("cat", "nao");


            Visit v = new Visit();

            v.setNome_local(name);
            v.setDescricao_local(descr);
            v.setPreço(preco);
            v.setId_endereco(endereço);
            v.setEmail_local(email);
            v.setTelefone_local(telefone);
            v.setFuncionamento_local(funci);
            v.setLink(linkLocal);
            v.setId_organizador(idOrg);
            v.setCategoria(cat);
            v.setImagem_lugar(imageToStore);


            try {


                long id_event = dao.inserirLugar(v);
                startActivity(new Intent(getBaseContext(), MenuActivity.class));
                this.finish();

            } catch (Exception er) {
                Toast.makeText(this, "erro" + er, Toast.LENGTH_SHORT).show();
            }
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try{
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data.getData() != null) {

            imageFilePath = data.getData();
            imageToStore = MediaStore.Images.Media.getBitmap(this.getContentResolver(),imageFilePath);
            imageEvent.setImageBitmap(imageToStore);


        }

            }catch (Exception e){
                e.printStackTrace();
            }
        }


    public void choose(View view){
        Intent i = new Intent();
        i.setType("image/*");

        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(i,REQUEST_CODE_GALLERY);

    }



    public void onFragmentViewCreated2(View view) {
        imageEvent = view.findViewById(R.id.imageViewEvent);
        final TextView edit = view.findViewById(R.id.editEnd);
        Button bt = findViewById(R.id.button8);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Vaipromapa(edit);
            }
        });




    }

    private void Vaipromapa(TextView edit) {
        SharedPreferences preferences = getBaseContext().getSharedPreferences("local", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("loc", edit.getText().toString() );
        editor.commit();
        startActivity(new Intent(this, MapsActivity.class));
    }


    public void onFragmentViewCreatedAdd(View view) {

        Button evt, visit;
        evt = findViewById(R.id.event);
        visit = findViewById(R.id.visit);

        evt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameCad,new addEventFragment()).commit();
            }
        });
        visit.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameCad,new addEventFragment2()).commit();
            }
        });

    }

    public void onFragmentViewCreated3(View view) {
        imageEvent = view.findViewById(R.id.imageViewEvent);
        final TextView edit = view.findViewById(R.id.editEnderecoLocal);
        Button bt = findViewById(R.id.button9);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Vaipromapa(edit);
            }
        });
    }

    public void onFragmentViewCreatedMenu(View view) {


//        recyclerView = view.findViewById(R.id.RecyclerPesq);
//
//        layoutManager = new LinearLayoutManager(this);
//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setHasFixedSize(true);





    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        MenuItem myActionMenuItem = menu.findItem(R.id.menuSearch);
        SearchView searchView = (SearchView)myActionMenuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){

            @Override
            public boolean onQueryTextSubmit(String query) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, new MenuEventVisitFragment()).commit();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, new SearchResultFragment()).commit();

                if(TextUtils.isEmpty(newText)){
                    adapter.filter("");
                    listView.clearTextFilter();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_eventVisit, new MenuEventVisitFragment()).commit();

                }else {
                    adapter.filter(newText);

                }
                return true;
            }
        });

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
                if(id==R.id.Settings){
                   this.finish();
                }


        return super.onOptionsItemSelected(item);
    }

    public void search(View view) {

        listView = view.findViewById(R.id.listt);

        listView.setAdapter(adapter);
    }

    public void onFragmentViewCreatedEvent(View view, List<Event> eventos) {
        RecyclerView myrecyclerview = view.findViewById(R.id.recycler);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 1);//Parameter: context, number of columns
        myrecyclerview.setLayoutManager(layoutManager);
        AdapterEvent adapter = new AdapterEvent(eventos);
        myrecyclerview.setAdapter(adapter);


    }

    public void onFragmentViewCreatedVisi(View view, List<Visit> visit) {
        RecyclerView recyclerview = view.findViewById(R.id.recyclerView2);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 1);//Parameter: context, number of columns
        recyclerview.setLayoutManager(layoutManager);
        AdapterVisit adapter = new AdapterVisit(visit);
        recyclerview.setAdapter(adapter);


    }
}


//
//











