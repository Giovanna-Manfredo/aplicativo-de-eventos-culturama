package com.tccetec.culturama.ui.usuarios;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;


import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.visit.Visit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Usuarios implements Serializable {

    private Integer id;
    private String nome;
    private String senha;
    private String email;
    private String telefone;
    private String dataNasc;
    private Boolean termos;
    private String[] categorias;
    private Bitmap imagem_user;
    private String endereco;



    public Usuarios() {
    }

    public Usuarios(Integer id, String nome, String senha, String email, String telefone, String dataNasc, Boolean termos, String[] categorias, Bitmap imagem_user, String endereco) {
        this.id = id;
        this.nome = nome;
        this.senha = senha;
        this.email = email;
        this.telefone = telefone;
        this.dataNasc = dataNasc;
        this.termos = termos;
        this.categorias = categorias;
        this.imagem_user = imagem_user;
        this.endereco = endereco;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void getImagem_user(byte[] Imagem_user) {
        final Bitmap bt = BitmapFactory.decodeByteArray(Imagem_user, 0, Imagem_user.length);
        this.imagem_user = bt;
    }
    public Bitmap getImagem_user() {
        return imagem_user;
    }

    public void setImagem_user(Bitmap imagem_user) {
        this.imagem_user = imagem_user;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public Boolean getTermos() {
        return termos;
    }

    public void setTermos(Boolean termos) {
        this.termos = termos;
    }

    public String[] getCategorias() {
        return categorias;
    }

    public void setCategorias(String[] categorias) {
        this.categorias = categorias;
    }
}