package com.tccetec.culturama;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.BdCulturama;
import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;
import com.tccetec.culturama.ui.visit.Visit;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class editActivity extends AppCompatActivity {
TextView textView;
TextView textView2;
TextView textView3;
TextView textView4;
TextView textView5;
TextView textView6;
TextView textView7;
TextView textView8;
    Bitmap foto;
    CulturamaDAO dao;
private static final int PICK_IMAGE_REQUEST = 100;
 String link ;
    String id;
    Bitmap bt;
    int idOrg;
    ImageView objectImageView;
    private Uri imagePath ;
    Spinner editSpinner;
    String id_e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
         editSpinner = findViewById(R.id.spinnerCat);

         Button b = findViewById(R.id.button5);


         b.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 cancel(v);
             }
         });



        try {



        }catch (Exception e){
            Toast.makeText(this, "erro no find", Toast.LENGTH_SHORT).show();
        }

        SharedPreferences preferences = getSharedPreferences("ARQUIVO_PREFERENCIA", 0);

            id_e =  preferences.getString("id", null);

        byte[] bt2 = getIntent().getByteArrayExtra("ImagemEvent");
        Bitmap imagem = BitmapFactory.decodeByteArray(bt2,0,bt2.length);





        SharedPreferences sp = getApplication().getSharedPreferences("ArquivoPreferencia", Context.MODE_PRIVATE);
        idOrg = sp.getInt("id",0);



                dao = new CulturamaDAO(this);
                Event ev = new Event();


        Spinner spinner = findViewById(R.id.spinnerCat);
        ArrayAdapter<CharSequence> adapt = ArrayAdapter.createFromResource(this, R.array.Categorias, android.R.layout.simple_spinner_item);
        adapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapt);



        try {


                    ev = dao.pegarEvent(id_e);

                    objectImageView = findViewById(R.id.imageViewEvent2);


                }catch (Exception e){
                    Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
                }


                    textView = this.findViewById(R.id.editNome);
                    String namePut = ev.getNome_evento();
                    textView.setText(namePut);

                    textView2 = findViewById(R.id.editPre);
                    String namePreço = ev.getPreco_evento();
                    textView2.setText(namePreço);

                    textView3 = findViewById(R.id.editDesc);
                    String nameDes = ev.getDescricao_evento();
                    textView3.setText(nameDes);

                    textView4 = findViewById(R.id.editData);
                    String nameData = ev.getData_evento();
                    textView4.setText(nameData);

                    textView5 = findViewById(R.id.editHoraEntre);
                    String namHoraE = ev.getHorario_entrada();
                    textView5.setText(namHoraE);

                    textView6 = findViewById(R.id.editHoraSai);
                    String namHoraS = ev.getHorario_saida();
                    textView6.setText(namHoraS);

                    textView7 = findViewById(R.id.editEnd);
                    String nameEnd = ev.getNum_endereco();
                    textView7.setText(nameEnd);

                    textView8 = findViewById(R.id.editLink);
                    String nameL = ev.getLink_evento();
                    textView8.setText(nameL);





       foto = dao.recuperaFotoE(ev.getId());
        objectImageView.setImageBitmap(imagem);
        Button bt = this.findViewById(R.id.btnImage);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage(v);
            }
        });





    }

    private void cancel(View v) {

        this.finish();

    }

    public void Delet(View view){

        SharedPreferences preferences = getSharedPreferences("ARQUIVO_PREFERENCIA", 0);

        String id_e =  preferences.getString("id", null);

        dao.deleteE(id_e);
        this.finish();
        Intent intent = new Intent(editActivity.this, MenuActivity.class);
        startActivity(intent);

    }


    public void Altere(View view){


        if(bt == null){
            bt= foto;
        }

        TextView linkText = this.findViewById(R.id.editLink);
        link = linkText.getText().toString();

        TextView nomeText = this.findViewById(R.id.editNome);
       String nome = nomeText.getText().toString();

        TextView descText = this.findViewById(R.id.editDesc);
        String desc = descText.getText().toString();

        TextView dataText = this.findViewById(R.id.editData);
        String data = dataText.getText().toString();


        TextView horaEntre = this.findViewById(R.id.editHoraEntre);
        String horaE = horaEntre.getText().toString();

        TextView horaSai = this.findViewById(R.id.editHoraSai);
        String horaS = horaSai.getText().toString();

        TextView endeText = this.findViewById(R.id.editEnd);
        String end = endeText.getText().toString();

        TextView precoText = this.findViewById(R.id.editPre);
        String preco = precoText.getText().toString();



        if(nome.trim().equals("")||data.trim().equals("")||end.trim().equals("")|| desc.trim().equals("")||horaS.trim().equals("")||horaE.trim().equals("")){
            Toast.makeText(this, "Informações ou Foto Faltando", Toast.LENGTH_SHORT).show();
        }else{


            String dataDigitadaStr = data; // Ex: "04/05/2010"


            SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
            Date dataDigitada = null;
            try {
                dataDigitada= formater.parse(dataDigitadaStr);

                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                assert dataDigitada != null;
                String dataa = dateFormat.format(dataDigitada);

                if (!dataDigitadaStr.equals(dataa)) {

                    Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
                    Log.d("data",dataa);
                    Log.d("data",dataDigitadaStr);


                }else{

                    if(hora(horaS) == true) {


                        if(hora(horaE) == true) {


                            Date hoje = new Date();
                            if(dataDigitada.getTime() <= hoje.getTime()){
                                Toast.makeText(this, "A data é menor que a data atual", Toast.LENGTH_SHORT).show();

                            }else {



                                String s = editSpinner.getSelectedItem().toString();



                                long idd = dao.AlterarEvent(id_e,nome,preco,desc,link,s,horaE,horaS,bt,idOrg,end,data);


                                Intent intent = new Intent(editActivity.this, MenuActivity.class);
                                startActivity(intent);
                                this.finish();

                            }

                        }else {
                            Toast.makeText(this, "Horario de Entrada invalido", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(this, "Horario de saida invalido", Toast.LENGTH_SHORT).show();
                    }




                }




            } catch (ParseException e) {
                Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
            }



        }

    }

    public  boolean  hora(String args) {

        if( args.length()<5) {
            return false;
        }else {
            String hora = args;

            // separa a hora o minuto e segundo em um array
            String[] hms = hora.split(":");

            int horas = Integer.parseInt(hms[0]);
            int minutos = Integer.parseInt(hms[1]);


            if (horas > 23) {

                return false;
            }else{

                if(minutos > 59){
                    return false;
                }else{
                    return true;
                }


            }

        }

    }




    public void chooseImage(View objectView){
        try{

            Intent objectIntent = new Intent();
            objectIntent.setType("image/*");
            objectIntent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);
        }catch (Exception e){

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode ==RESULT_OK && data!=null && data.getData() !=null ){
                imagePath = data.getData();
                bt = MediaStore.Images.Media.getBitmap(getContentResolver(),imagePath);

                objectImageView.setImageBitmap(bt);




            }
        }catch (Exception e){

        }

        }
}