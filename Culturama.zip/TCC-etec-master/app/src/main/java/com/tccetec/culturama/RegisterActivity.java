package com.tccetec.culturama;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.tccetec.culturama.BD.BdCulturama;
import com.tccetec.culturama.BD.CulturamaDAO;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class RegisterActivity extends AppCompatActivity {
    private EditText nome;
    private EditText senha;
    private EditText email;
    private EditText telefone;
    private EditText dataNasc;
    private ImageView img;
    private static final int PICK_IMAGE_REQUEST = 100;
    private Uri imagePath ;
    Bitmap bt;
    CulturamaDAO dao;
    private byte[] ImageInBytes;
    private ImageButton imgB;
    private ByteArrayOutputStream objectByteArrayOutPutScream;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        img = findViewById(R.id.imageView3);
        nome = findViewById(R.id.editNomeLocal);
        senha = findViewById(R.id.editSenha);
        email = findViewById(R.id.editEmailLogin);
        telefone = findViewById(R.id.editPhone);
        dataNasc = findViewById(R.id.editDate);

    // dao = new CulturamaDAO(getBaseContext());
        Button go = findViewById(R.id.btnProx);
        imgB = findViewById(R.id.imageButton4);

        imgB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


              v(v);
            }
        });


        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(bt==null||nome.getText().toString().trim().equals("")||senha.getText().toString().trim().equals("")||email.getText().toString().trim().equals("")||telefone.getText().toString().trim().equals("")||dataNasc.getText().toString().trim().equals("")){
                    Toast.makeText(RegisterActivity.this, "Informações ou Foto Faltando", Toast.LENGTH_SHORT).show();
                }else{
                    cad();
                }




            }
        });

    }

    public void v(View view){
        this.finish();
    }
    private boolean validateEmailFormat(final String email) {
        if (android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return true;
        }
        return false;
    }
    public void cad(){
        Boolean emailvalid = validateEmailFormat(email.getText().toString());
        Intent i = new Intent(getApplicationContext(), RegisterActivityDois.class);
        Bundle bd = new Bundle();
        bd.putString("nome", nome.getText().toString());
        if(emailvalid == true){
            bd.putString("email", email.getText().toString());

            if( senha.getText().toString().length()<8){
                Toast.makeText(this, "A senha precisa ter mais de 8 digitos", Toast.LENGTH_LONG).show();


            }else{
                bd.putString("senha", senha.getText().toString());
                if( telefone.getText().toString().length()<13){
                    Toast.makeText(this, "Telefone com digitos insuficientes", Toast.LENGTH_LONG).show();

                }else{
                    bd.putString("phone", telefone.getText().toString());


                    String dataDigitadaStr = dataNasc.getText().toString(); // Ex: "04/05/2010"


                    SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
                    Date dataDigitada = null;
                    try {
                        dataDigitada= formater.parse(dataDigitadaStr);

                        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        assert dataDigitada != null;
                        String data = dateFormat.format(dataDigitada);

                        if (!dataDigitadaStr.equals(data)) {

                            Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
                            Log.d("data",data);
                            Log.d("data",dataDigitadaStr);
                        }else{

                            finalizarCad(dataDigitada,bd,i);

                        }




                    } catch (ParseException e) {
                        Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
                    }


                }

            }

        }else{
            Toast.makeText(this, "email invalido", Toast.LENGTH_SHORT).show();
        }






    }



    public void finalizarCad(Date dataDigitada, Bundle bd, Intent i){

        Date hoje = new Date();

        if(dataDigitada.getTime() >= hoje.getTime()){
            Toast.makeText(this, "Data digitada maior que a data atual", Toast.LENGTH_SHORT).show();

        }else{

            dao = new CulturamaDAO(this);

            Boolean veri = dao.Verifica(email.getText().toString());

            if(veri == false) {

                bd.putString("dataNasc", dataNasc.getText().toString());
                objectByteArrayOutPutScream = new ByteArrayOutputStream();
                bt.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
                ImageInBytes = objectByteArrayOutPutScream.toByteArray();

                bd.putByteArray("IMG", ImageInBytes);
                i.putExtras(bd);
                startActivity(i);

            }else{

                Toast.makeText(this, "Este email já foi cadastrado!", Toast.LENGTH_SHORT).show();

            }
        }




    }



    public void chooseImage(View objectView){
        try{

            Intent objectIntent = new Intent();
            objectIntent.setType("image/*");
            objectIntent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);
        }catch (Exception e){

        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode ==RESULT_OK && data!=null && data.getData() !=null ){
                imagePath = data.getData();
                bt = MediaStore.Images.Media.getBitmap(getContentResolver(),imagePath);

                img.setImageBitmap(bt);

            }

            if(requestCode != PICK_IMAGE_REQUEST){
                Toast.makeText(this, "imagem invalida", Toast.LENGTH_SHORT).show();
            }



        }catch (Exception e){
            Toast.makeText(this, "imagem invalida", Toast.LENGTH_SHORT).show();
        }

    }



}