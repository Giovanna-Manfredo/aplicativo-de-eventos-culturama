package com.tccetec.culturama.ui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class ModelItem {
    public Integer idEV;
    public String nome;
    public int OrgEV;
    private Bitmap imagem;
    boolean eEvent;

    public ModelItem() {
    }

    public ModelItem(Integer idEV, String nome, int orgEV, Bitmap imagem, boolean eEvent) {
        this.idEV = idEV;
        this.nome = nome;
        OrgEV = orgEV;
        this.imagem = imagem;
        this.eEvent = eEvent;
    }



    public void setImagem(Bitmap imagem) {
        this.imagem = imagem;
    }


    public boolean iseEvent() {
        return eEvent;
    }

    public void seteEvent(boolean eEvent) {
        this.eEvent = eEvent;
    }

    public Bitmap getImagem() {
        return this.imagem;
    }

    public void setImagem(byte[] imagem) {
        final Bitmap bt = BitmapFactory.decodeByteArray(imagem, 0, imagem.length);
        this.imagem = bt;

    }

    public Integer getIdEV() {
        return this.idEV;
    }

    public String getNome() {
        return this.nome;
    }

    public int getOrgEV() {
        return this.OrgEV;
    }


    public void setIdEV(Integer idEV) {
        this.idEV = idEV;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setOrgEV(int orgEV) {
        OrgEV = orgEV;
    }

    public void getImagem(byte[] blob) {
        final Bitmap bt = BitmapFactory.decodeByteArray(blob, 0, blob.length);
        this.imagem = bt;


    }
}
