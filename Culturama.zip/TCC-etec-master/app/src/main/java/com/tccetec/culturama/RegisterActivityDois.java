package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RegisterActivityDois extends AppCompatActivity {

    CheckBox cat1, cat2, cat3, cat4, cat5, cat6, cat7,cat8,cat9;
    List<String> check = new ArrayList<String>();
    Button voltar;
    ImageButton imgB;
    public int maximo = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_dois);

        cat1 = findViewById(R.id.cat1);
        cat2 = findViewById(R.id.cat2);
        cat3 = findViewById(R.id.cat3);
        cat4 = findViewById(R.id.cat4);
        cat5 = findViewById(R.id.cat5);
        cat6 = findViewById(R.id.cat6);
        cat7 = findViewById(R.id.cat7);
        cat8 = findViewById(R.id.cat8);
        cat9 = findViewById(R.id.cat9);

        Button go = findViewById(R.id.btnProx);
        voltar = findViewById(R.id.button4);
        imgB = findViewById(R.id.imageButton4);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v(v);
            }
        });

        imgB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v(v);
            }
        });



        check.clear();

        cat1.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat1.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat1.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat2.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat2.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat2.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat3.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat3.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat3.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat4.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat4.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat4.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat5.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat5.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat5.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat6.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat6.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat6.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat7.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat7.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat7.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat8.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat8.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat8.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });

        cat9.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                if (cat9.isChecked() == false) {


                    maximo = maximo - 1;

                }else{

                    if (maximo < 7) {
                        maximo++;
                    } else {

                        cat9.setChecked(false);
                        Toast.makeText(RegisterActivityDois.this, "Limite de 6 categorias", Toast.LENGTH_SHORT).show();


                    }

                }

            }
        });








        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(cat1.isChecked()){
                    check.add(cat1.getText().toString());
                }
                if(cat2.isChecked()){
                    check.add(cat2.getText().toString());
                }
                if(cat3.isChecked()){
                    check.add(cat3.getText().toString());
                }
                if(cat4.isChecked()){
                    check.add(cat4.getText().toString());
                }
                if(cat5.isChecked()){
                    check.add(cat5.getText().toString());
                }
                if(cat6.isChecked()){
                    check.add(cat6.getText().toString());
                }
                if(cat7.isChecked()){
                    check.add(cat7.getText().toString());
                }
                if(cat8.isChecked()){
                    check.add(cat8.getText().toString());
                }
                if(cat9.isChecked()){
                    check.add(cat9.getText().toString());
                }

                //Toast para testar se o dados estao paassando
                Intent dadosRecebidos = getIntent();
                Bundle extras = dadosRecebidos.getExtras();
                String nomePessoa = extras.getString("nome");
                String senha = extras.getString("senha");
                String email = extras.getString("email");
                String phone = extras.getString("phone");
                String dataNasc = extras.getString("dataNasc");
                byte[] img = extras.getByteArray("IMG");

                Intent i = new Intent(getBaseContext(),RegisterActivityTres.class);
                Bundle bd = new Bundle();
                bd.putStringArray("categorias", new String[]{String.valueOf(check)});
                bd.putString("nome", nomePessoa);
                bd.putString("senha",  senha);
                bd.putString("email", email);
                bd.putString("phone",  phone);
                bd.putString("dataNasc", dataNasc);
                bd.putByteArray("IMG", img);
                i.putExtras(bd);
                startActivity(i);
                  }




        });
    }

    private void v(View v) {
        this.finish();
    }


}