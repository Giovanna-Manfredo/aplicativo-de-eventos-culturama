package com.tccetec.culturama.ui.visit;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.R;
import com.tccetec.culturama.VisitActivity;
import com.tccetec.culturama.editActivity;
import com.tccetec.culturama.editVActivity;

import java.util.List;

public class AdapterMyVisit extends RecyclerView.Adapter<AdapterMyVisit.MyViewHolder> {
    Context context;
    List<Visit> visitList;
    CulturamaDAO dao;
    public AdapterMyVisit(List<Visit> visitList) {
        this.visitList = visitList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (context == null) {
            context = parent.getContext();
        }

        View view = LayoutInflater.from(context).inflate(R.layout.layout_visit, parent, false);
        return new AdapterMyVisit.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.nameVisit.setText(visitList.get(position).getNome_local());

        holder.DataVisit.setText(visitList.get(position).getEmail_local());
        holder.imageVisit.setImageBitmap(visitList.get(position).getImagem_lugar());

        holder.CardVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = context.getSharedPreferences("ARQUIVO_PREFE", 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("id", String.valueOf(visitList.get(position).getId()));
                editor.commit();

                dao = new CulturamaDAO(context);
                byte[] img = dao.recuperaImagV(visitList.get(position).getId());
                Intent intent=new Intent(context, editVActivity.class);

                intent.putExtra("idVisit", visitList.get(position).getId());
                intent.putExtra("nameVisit", visitList.get(position).getNome_local());
                intent.putExtra("emailVisit", visitList.get(position).getEmail_local());
                intent.putExtra("desVisit", visitList.get(position).getDescricao_local());
                intent.putExtra("teleVisit", visitList.get(position).getTelefone_local());
                intent.putExtra("funcVisit", visitList.get(position).getFuncionamento_local());
                intent.putExtra("endVisit", visitList.get(position).getId_endereco());
                intent.putExtra("preçoVisit", visitList.get(position).getPreço());
                intent.putExtra("linkVisit", visitList.get(position).getLink());
                intent.putExtra("imageVisit", img);
                intent.putExtra("orgVisit", visitList.get(position).getId_organizador());


                v.getContext().startActivity(intent);


            }
        });

    }

    @Override
    public int getItemCount() {
        return visitList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{

        private ImageView imageVisit;
        private TextView nameVisit;
        private TextView DescVisit;
        private TextView DataVisit;
        private CardView CardVisit;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageVisit = itemView.findViewById(R.id.imageVisit);
            nameVisit = itemView.findViewById(R.id.nameVisit);

            DataVisit = itemView.findViewById(R.id.DataVisit);
            CardVisit = itemView.findViewById(R.id.cardVisit);

        }
        }
}
