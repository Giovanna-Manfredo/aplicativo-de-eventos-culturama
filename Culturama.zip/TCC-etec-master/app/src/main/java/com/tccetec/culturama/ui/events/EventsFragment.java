package com.tccetec.culturama.ui.events;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.tccetec.culturama.AdapterCat;
import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.MenuActivity;
import com.tccetec.culturama.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class EventsFragment extends Fragment {
CulturamaDAO dao;
RecyclerView RecyCat;


    private Event[] Evento = {new Event(1,"Nome do evento","Vei ser loko","01/02/333",null, null, 0,null,null,null, null,null)};


    private RecyclerView myrecyclerview;
    private List<Event> eventos = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment

//    <item>Outros</item>
//        <item>Culturais</item>
//        <item>Festas</item>
//        <item>Exposições</item>
//        <item>Empresariais</item>
//        <item>Educacionais e Acadêmicos</item>
//        <item>Esportes</item>
//        <item>Torneios</item>
//        <item>Parques</item>
//        <item>Ciência e Tecnologia</item>

        View view = inflater.inflate(R.layout.fragment_events, container, false);
        RecyCat = view.findViewById(R.id.recyclerViewCat);
        List<String> categoria = new ArrayList<>();
        categoria.add("Outros");
        categoria.add("Culturais");
        categoria.add("Festas");
        categoria.add("Exposições");
        categoria.add("Empresariais");
        categoria.add("Educacionais e Acadêmicos");
        categoria.add("Esportes");
        categoria.add("Torneios");
        categoria.add("Parques");
        categoria.add("Ciência e Tecnologia");



        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        RecyCat.setLayoutManager(layoutManager);
        AdapterCat adapter = new AdapterCat(categoria,view);
        RecyCat.setAdapter(adapter);
        myrecyclerview = view.findViewById(R.id.recycler);
        initView(view);
       return view;
    }

    private void initView(View view) {
        ((MenuActivity) getActivity()).onFragmentViewCreatedEvent(view,eventos); // Metodo que deve ser implementado na Activity

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initEvents();
    }



    private void initEvents() {
        eventos.clear();
        dao = new CulturamaDAO(getContext());
      Event[] list = dao.obterEventos();

        if(list == null) {
            for (int i = 0; i < Evento.length; i++) {

                eventos.add(Evento[i]);
            }
        }else{
            for (int i = 0; i < list.length; i++) {

                eventos.add(list[i]);
            }
        }
    }

    public void event(View view){

    }

    public void visit(View view){

    }


}