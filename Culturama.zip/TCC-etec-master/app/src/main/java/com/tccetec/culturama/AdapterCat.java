package com.tccetec.culturama;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.AdapterEvent;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.events.EventsFragment;
import com.tccetec.culturama.ui.visit.Visit;

import java.util.ArrayList;
import java.util.List;

public class AdapterCat extends RecyclerView.Adapter<AdapterCat.MyViewHolder> {
    CulturamaDAO dao;
    Context context;
    List<String> eventList;
    View view;

    public AdapterCat(List<String> eventos,View cont) {
        eventList = eventos;
        view = cont;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (context == null) {
            context = parent.getContext();
        }

        View view = LayoutInflater.from(context).inflate(R.layout.layout_ca, parent, false);

        return new AdapterCat.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
       holder.cat.setText(eventList.get(position));

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Event[] e;
              List<Event> eventos = new ArrayList<>();
              dao = new CulturamaDAO(context);
              e = dao.obterTodosEventosCat(holder.cat.getText().toString());

                for (int i = 0; i < e.length; i++) {

                    eventos.add(e[i]);
                }

                MenuActivity m = new MenuActivity();
                m.onFragmentViewCreatedEvent(view,eventos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{


        private CardView card;
        TextView cat;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.cardCat);
           cat = itemView.findViewById(R.id.NameCategoria);


        }
    }

}
