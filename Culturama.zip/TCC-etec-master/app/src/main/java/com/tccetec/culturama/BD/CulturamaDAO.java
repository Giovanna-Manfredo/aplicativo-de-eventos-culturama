package com.tccetec.culturama.BD;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteQueryBuilder;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.Toast;

import com.tccetec.culturama.ui.ModelItem;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;
import com.tccetec.culturama.ui.visit.Visit;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CulturamaDAO {
    private BdCulturama conexao;
    private SQLiteDatabase banco;
    private ByteArrayOutputStream objectByteArrayOutPutScream;
    private byte[] ImageInBytes;
    private Usuarios usuario;
    Bitmap bitmapImage;
    public CulturamaDAO(Context context) {
        try {
            conexao = new BdCulturama(context);
            banco = conexao.getWritableDatabase();
        } catch (Exception e) {
            Toast.makeText(context, "erro no bd:" + e, Toast.LENGTH_SHORT).show();
        }

    }

    public long inserirEvent(Event event) {
        Bitmap imageToStoreBipmap = event.getImagem_evento();
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        imageToStoreBipmap.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();

        ContentValues value = new ContentValues();
        value.put("nome_evento", event.getNome_evento());
        value.put("preco_evento", event.getPreco_evento());
        value.put("descricao_evento", event.getDescricao_evento());
        value.put("link_evento", event.getLink_evento());
        value.put("cat_evento", event.getCat_evento());
        value.put("horario_entrada", event.getHorario_entrada());
        value.put("horario_saida", event.getHorario_saida());
        value.put("imagem_evento", ImageInBytes);
        value.put("id_organizador", event.getId_organizador());
        value.put("num_endereco", event.getNum_endereco());
        value.put("data_evento", event.getData_evento());
        return banco.insert(BdCulturama.tab_evento, null, value);

    }


    public int AlterarEvent(String id, String nome, String preço, String Desc, String Link, String Cat, String HoraEn, String HoraS , Bitmap bt, int Org, String end, String data ) {
        Bitmap imageToStoreBipmap = bt;
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        imageToStoreBipmap.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();


        ContentValues value = new ContentValues();
        value.put("nome_evento",nome);
        value.put("preco_evento", preço);
        value.put("descricao_evento",   Desc);
        value.put("link_evento", Link);
        value.put("cat_evento",Cat);
        value.put("horario_entrada", HoraEn);
        value.put("horario_saida",HoraS);
        value.put("imagem_evento", ImageInBytes);
        value.put("id_organizador", Org);
        value.put("num_endereco",end);
        value.put("data_evento", data);

        String[] args ={id};
        return banco.update(BdCulturama.tab_evento, value,"id=?", args);

    }

    public int AlterarVisit(String id, String nome, String email, String Desc, String telefone, String Cat, String func, String ende , Bitmap bt, int Org, String pre, String link ) {
        Bitmap imageToStoreBipmap = bt;
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        imageToStoreBipmap.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();


        ContentValues value = new ContentValues();
        value.put(BdCulturama.nome_local,nome);
        value.put(BdCulturama.email_local, email);
        value.put(BdCulturama.descricao_local,   Desc);
        value.put(BdCulturama.telefone_local, telefone);
        value.put(BdCulturama.categoria,Cat);
        value.put(BdCulturama.funcionamento_local, func);
        value.put(BdCulturama.id_endereco,ende);
        value.put(BdCulturama.imagem_lugar, ImageInBytes);
        value.put(BdCulturama.id_organizador_local, Org);
        value.put(BdCulturama.preço,pre);
        value.put(BdCulturama.link, link);

        String[] args ={id};
        return banco.update(BdCulturama.tab_visit, value,"id=?", args);

    }

    public void deleteE(String id)
    {
        try
        {
            String[] args = {id};
            banco.delete(BdCulturama.tab_evento, "id = ?", args);
            banco.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void deleteV(String id)
    {
        try
        {
            String[] args = {id};
            banco.delete(BdCulturama.tab_visit, "id = ?", args);
            banco.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public int AlterarUser(String id, String nome, String email, String senha, String end, String tele, String nasc , Bitmap bt) {
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        bt.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();


        ContentValues value = new ContentValues();
        value.put(BdCulturama.nome_usuario,nome);
        value.put(BdCulturama.email_usuario, email);
        value.put(BdCulturama.senha_usuario,   senha);
        value.put(BdCulturama.endereco_usuario, end);
        value.put(BdCulturama.telefone_usuario, tele);
        value.put(BdCulturama.dataNasc_usuario,nasc);
        value.put(BdCulturama.imagem_user, ImageInBytes);


        String[] args ={id};
        return banco.update(BdCulturama.tab_user, value,"id=?", args);

    }





    public long inserirLugar(Visit visit) {
        Bitmap imageToStoreBipmap = visit.getImagem_lugar();
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        imageToStoreBipmap.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();

        ContentValues value = new ContentValues();
        value.put("nome_local", visit.getNome_local());
        value.put("email_local", visit.getEmail_local());
        value.put("descricao_local", visit.getDescricao_local());
        value.put("telefone_local", visit.getTelefone_local());
        value.put("funcionamento_local", visit.getFuncionamento_local());
        value.put("id_endereco", visit.getId_endereco());
        value.put("preço", visit.getPreço());
        value.put("link", visit.getLink());
        value.put("categoria", visit.getCategoria());
        value.put("id_organizador", visit.getId_organizador());
        value.put("imagem_lugar",ImageInBytes);
        return banco.insert(BdCulturama.tab_visit, null, value);

    }

    public long inserir(Usuarios usuarios) {
        Bitmap imageToStoreBipmap = usuarios.getImagem_user();
        objectByteArrayOutPutScream = new ByteArrayOutputStream();
        imageToStoreBipmap.compress(Bitmap.CompressFormat.JPEG, 100, objectByteArrayOutPutScream);
        ImageInBytes = objectByteArrayOutPutScream.toByteArray();

        ContentValues values = new ContentValues();
        values.put("nome_usuario", usuarios.getNome());
        values.put("senha_usuario", usuarios.getSenha());
        values.put("email_usuario", usuarios.getEmail());
        values.put("telefone_usuario", usuarios.getTelefone());
        values.put("dataNasc_usuario", usuarios.getDataNasc());
        values.put( BdCulturama.imagem_user, ImageInBytes);
        values.put("categorias_preferencias", Arrays.toString(usuarios.getCategorias()));
        return banco.insert(BdCulturama.tab_user, null, values);

    }
    public byte[] recuperaImag(Integer id){
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT "+BdCulturama.imagem_evento+" FROM " + BdCulturama.tab_evento + " WHERE " + BdCulturama.id_event + " = ?", new String[]{String.valueOf(id)});

        if (cursor != null) {
            cursor.moveToFirst();
        }

        byte[] img = cursor.getBlob(0);

        return img;
    }

    public byte[] recuperaImagV(Integer id){
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT "+BdCulturama.imagem_lugar+" FROM " + BdCulturama.tab_visit + " WHERE " + BdCulturama.id_local + " = ?", new String[]{String.valueOf(id)});

        if (cursor != null) {
            cursor.moveToFirst();
        }

        byte[] img = cursor.getBlob(0);

        return img;
    }

    public Bitmap recuperaPerfil(Integer id){
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT "+BdCulturama.imagem_user+" FROM " + BdCulturama.tab_user + " WHERE " + BdCulturama.id + " = ?", new String[]{String.valueOf(id)});

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Bitmap img = BitmapFactory.decodeByteArray(cursor.getBlob(0),0,cursor.getBlob(0).length);

    return img;
    }

    public Bitmap recuFotoV(Integer id){
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT "+BdCulturama.imagem_lugar+" FROM " + BdCulturama.tab_visit + " WHERE " + BdCulturama.id_local + " = ?", new String[]{String.valueOf(id)});

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Bitmap img = BitmapFactory.decodeByteArray(cursor.getBlob(0),0,cursor.getBlob(0).length);

        return img;
    }


    public Bitmap recuperaFotoE(Integer id){
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT "+BdCulturama.imagem_evento+" FROM " + BdCulturama.tab_evento + " WHERE " + BdCulturama.id_event + " = ?", new String[]{String.valueOf(id)});

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Bitmap img = BitmapFactory.decodeByteArray(cursor.getBlob(0),0,cursor.getBlob(0).length);

        return img;
    }


    public Usuarios selectU(String email, String senha) {

        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE " + BdCulturama.email_usuario + " = ? AND " + BdCulturama.senha_usuario + " = ?", new String[]{email, senha});

        if (cursor != null) {
            cursor.moveToFirst();
        }



                 usuario = new Usuarios();

        usuario.setId(cursor.getInt(0));

       usuario.setNome( cursor.getString(1));
       usuario.setSenha(cursor.getString(2));
       usuario.setEmail(cursor.getString(3));
       usuario.setTelefone(cursor.getString(4));
       usuario.setDataNasc(cursor.getString(5));
       usuario.setEndereco(cursor.getString(6));
       usuario.setImagem_user(BitmapFactory.decodeByteArray(cursor.getBlob(7),0,cursor.getBlob(7).length));
        usuario.setCategorias(new String[]{cursor.getString(8)});
        return usuario;
    }


    public Usuarios selectId(Integer id) {

        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE " + BdCulturama.id +  " = ?", new String[]{String.valueOf(id)});

        if (cursor != null) {
            cursor.moveToFirst();
        }



        usuario = new Usuarios();

        usuario.setId(cursor.getInt(0));

        usuario.setNome( cursor.getString(1));
        usuario.setSenha(cursor.getString(2));
        usuario.setEmail(cursor.getString(3));
        usuario.setTelefone(cursor.getString(4));
        usuario.setDataNasc(cursor.getString(5));
        usuario.setEndereco(cursor.getString(6));
        usuario.setImagem_user(BitmapFactory.decodeByteArray(cursor.getBlob(7),0,cursor.getBlob(7).length));
        usuario.setCategorias(new String[]{cursor.getString(8)});
        return usuario;
    }
    public Visit pegarVisit(String id){

        SQLiteDatabase db = conexao.getReadableDatabase();
        Visit newEvent = new Visit () ;
        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        Cursor cursor = db.rawQuery("SELECT "+BdCulturama.id_local+","+BdCulturama.nome_local+","+BdCulturama.email_local+","+BdCulturama.descricao_local+","+BdCulturama.telefone_local+","+BdCulturama.funcionamento_local+","+BdCulturama.id_endereco+","+BdCulturama.preço+","+BdCulturama.link+","+BdCulturama.categoria+","+BdCulturama.id_organizador_local+" FROM " + BdCulturama.tab_visit + " WHERE " + BdCulturama.id_event +  " = ?", new String[]{String.valueOf(id)});

        if (cursor.moveToFirst ()) {
            do {

                newEvent.setId (cursor.getInt (0));
                newEvent.setNome_local (cursor.getString (1));
                newEvent.setEmail_local (cursor.getString (2));
                newEvent.setDescricao_local (cursor.getString (3));
                newEvent.setTelefone_local (cursor.getString (4));
                newEvent.setFuncionamento_local (cursor.getString (5));
                newEvent.setId_endereco (cursor.getString (6));
                newEvent.setPreço (cursor.getString (7));
                newEvent.setLink (cursor.getString (8));
                newEvent.setCategoria (cursor.getString (9));
                newEvent.setId_organizador (cursor.getInt (10));





            } while (cursor.moveToNext ()) ;
        }
        return newEvent;
    }
    public Event pegarEvent(String id){

        SQLiteDatabase db = conexao.getReadableDatabase();
        Event newEvent = new Event () ;
        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_evento + " WHERE " + BdCulturama.id_event +  " = ?", new String[]{String.valueOf(id)});

        if (cursor.moveToFirst ()) {
            do {

                newEvent.setId (cursor.getInt (0));
                newEvent.setNome_evento (cursor.getString (1));
                newEvent.setDescricao_evento (cursor.getString (2));
                newEvent.setData_evento (cursor.getString (3));
                newEvent.setHorario_entrada (cursor.getString (4));
                newEvent.setHorario_saida (cursor.getString (5));
                newEvent.setId_organizador (cursor.getInt (6));
                newEvent.setNum_endereco (cursor.getString (7));
                newEvent.setPreco_evento (cursor.getString (8));
                newEvent.setLink_evento (cursor.getString (9));
                newEvent.setCat_evento (cursor.getString (10));



            } while (cursor.moveToNext ()) ;
        }
        return newEvent;
    }


    public Usuarios pegaUserName(int id){

        SQLiteDatabase db = conexao.getReadableDatabase();
        Usuarios newEvent = new Usuarios () ;
        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        Cursor cursor = db.rawQuery("SELECT "+BdCulturama.nome_usuario+" FROM " + BdCulturama.tab_user + " WHERE " + BdCulturama.id +  " = ?", new String[]{String.valueOf(id)});

        if (cursor.moveToFirst ()) {
            do {

                newEvent.setNome (cursor.getString (0));




            } while (cursor.moveToNext ()) ;
        }
        return newEvent;
    }



    public ArrayList<Event> listarEvents (){
        ArrayList<Event> eventos = new ArrayList <> () ;
        SQLiteDatabase db = conexao.getReadableDatabase();

        // Cursor cursor = db.query(BdCulturama.tab_user, new String[] {BdCulturama.id,BdCulturama.nome_usuario, BdCulturama.senha_usuario,BdCulturama.email_usuario,BdCulturama.telefone_usuario, BdCulturama.dataNasc_usuario, BdCulturama.aceito_termos, BdCulturama.categorias_preferencias}, BdCulturama.id + " = ?", new String[] {String.valueOf(id)}, null,null,null,null);
        Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_evento ,null);

        if (cursor.moveToFirst ()) {
            do {
                Event newEvent = new Event () ;
                newEvent.setId (cursor.getInt (0));
                newEvent.setNome_evento (cursor.getString (1));
                newEvent.setDescricao_evento (cursor.getString (2));
                newEvent.setData_evento (cursor.getString (3));
                newEvent.setHorario_entrada (cursor.getString (4));
                newEvent.setHorario_saida (cursor.getString (5));
                newEvent.setId_organizador (cursor.getInt (6));
                newEvent.setNum_endereco (cursor.getString (7));
                newEvent.setPreco_evento (cursor.getString (8));
                newEvent.setLink_evento (cursor.getString (9));
                newEvent.setCat_evento (cursor.getString (10));
                eventos.add (newEvent) ;


            } while (cursor.moveToNext ()) ;
        }
        return eventos;
    }

    public ArrayList<ModelItem> getModel(){

        SQLiteDatabase db = conexao.getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {BdCulturama.id_event,BdCulturama.nome_evento,BdCulturama.id_organizador,BdCulturama.imagem_evento};
        String table = BdCulturama.tab_evento;

        qb.setTables(table);
        Cursor c = qb.query(db,sqlSelect,null,null,null,null,null);

        List<ModelItem> result = new ArrayList<>();
        c.moveToFirst();

        while (!c.isAfterLast()) {
                String a = String.valueOf(c.getColumnIndex(BdCulturama.imagem_evento));


                ModelItem m = new ModelItem();
               m.setIdEV(c.getInt(c.getColumnIndex(BdCulturama.id_event)));
               m.setNome(c.getString(c.getColumnIndex(BdCulturama.nome_evento)));
               m.setOrgEV(c.getInt(c.getColumnIndex(BdCulturama.id_organizador)));
               m.seteEvent(true);
               m.setImagem(c.getBlob(Byte.parseByte(a)));

                result.add(m);

                c.moveToNext();

        }


        List<ModelItem> resultado = getModel2(result);

        return (ArrayList<ModelItem>) resultado;
    }
    public ArrayList<ModelItem> getModel2( List<ModelItem> mod){
        List<ModelItem> result = mod;
        SQLiteDatabase db = conexao.getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {BdCulturama.id_local,BdCulturama.nome_local,BdCulturama.id_organizador_local,BdCulturama.imagem_lugar};
        String table = BdCulturama.tab_visit;

        qb.setTables(table);
        Cursor c = qb.query(db,sqlSelect,null,null,null,null,null);

        if(c.moveToFirst()){
            do{
                String a = String.valueOf(c.getColumnIndex(BdCulturama.imagem_lugar));



                ModelItem m = new ModelItem();
                m.setIdEV(c.getInt(c.getColumnIndex(BdCulturama.id_local)));
                m.setNome(c.getString(c.getColumnIndex(BdCulturama.nome_local)));
                m.setOrgEV(c.getInt(c.getColumnIndex(BdCulturama.id_organizador_local)));
                m.seteEvent(false);
                m.setImagem(c.getBlob(Byte.parseByte(a)));
                result.add(m);
            }while (c.moveToNext());
        }


        return (ArrayList<ModelItem>) result;
    }


    public List<String> getNamesE(){

        SQLiteDatabase db = conexao.getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {BdCulturama.nome_evento};
        String table = BdCulturama.tab_evento;

        qb.setTables(table);
        Cursor c = qb.query(db,sqlSelect,null,null,null,null,null);
        List<String> result = new ArrayList<>();
        if(c.moveToFirst()){
            do{
               result.add(c.getString(c.getColumnIndex(BdCulturama.nome_evento)));
            }while (c.moveToNext());
        }

        List<String> resultado = getNamesE2(result);

        return  resultado;



    }
    public List<String> getNamesE2(List<String> s){
        List<String> result = s;
        SQLiteDatabase db = conexao.getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {BdCulturama.nome_local};
        String table = BdCulturama.tab_visit;

        qb.setTables(table);
        Cursor c = qb.query(db,sqlSelect,null,null,null,null,null);

        if(c.moveToFirst()){
            do{
                result.add(c.getString(c.getColumnIndex(BdCulturama.nome_local)));
            }while (c.moveToNext());
        }


        return  result;



    }


    public List<ModelItem> getEVByNAME(String name){

        SQLiteDatabase db = conexao.getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {BdCulturama.id_event,BdCulturama.nome_evento,BdCulturama.id_organizador};
        String table = BdCulturama.tab_evento;

        qb.setTables(table);
        Cursor c = qb.query(db,sqlSelect,BdCulturama.nome_evento + " LIKE ?",new String[]{"%"+name+"%"},null,null,null);
        List<ModelItem> result = new ArrayList<>();
        if(c.moveToFirst()){
            do{
                ModelItem m = new ModelItem();
//                m.setIdEV(c.getInt(c.getColumnIndex(BdCulturama.id_event)));
//                m.setNome(c.getString(c.getColumnIndex(BdCulturama.nome_evento)));
//                m.setOrgEV(c.getInt(c.getColumnIndex(BdCulturama.id_organizador)));

                result.add(m);
            }while (c.moveToNext());
        }

        List<ModelItem> resultado = getEVByNAME2(result,name);

        return (ArrayList<ModelItem>) resultado;


    }
    public List<ModelItem> getEVByNAME2(List<ModelItem> e, String name){
        List<ModelItem> result = e;
        SQLiteDatabase db = conexao.getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSelect = {BdCulturama.id_local,BdCulturama.nome_local,BdCulturama.id_organizador_local};
        String table = BdCulturama.tab_visit;

        qb.setTables(table);
        Cursor c = qb.query(db,sqlSelect,BdCulturama.nome_local + " LIKE ?",new String[]{"%"+name+"%"},null,null,null);

        if(c.moveToFirst()){
            do{
                ModelItem m = new ModelItem();
//                m.setIdEV(c.getInt(c.getColumnIndex(BdCulturama.id_local)));
//                m.setNome(c.getString(c.getColumnIndex(BdCulturama.nome_local)));
//                m.setOrgEV(c.getInt(c.getColumnIndex(BdCulturama.id_organizador_local)));

                result.add(m);
            }while (c.moveToNext());
        }



        return (ArrayList<ModelItem>) result;


    }

    public Boolean Verifica(String email){
        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE "+BdCulturama.email_usuario+" = ?", new String[]{email});

        if(cursor.getCount()>0){

            return true;

        }
        return false;
    }


        public Boolean logar(String email, String senha){
            SQLiteDatabase db = conexao.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + BdCulturama.tab_user + " WHERE "+BdCulturama.email_usuario+" = ? AND "+BdCulturama.senha_usuario+" = ?", new String[]{email, senha});

            if(cursor.getCount()>0){

                return true;

            }
            return false;
        }
    public Event[] obterEventos() {

        SQLiteDatabase db = conexao.getReadableDatabase();


        Cursor resultados = db.query(BdCulturama.tab_evento,
                new String[]{BdCulturama.id_event, BdCulturama.nome_evento, BdCulturama.descricao_evento,BdCulturama.data_evento,BdCulturama.imagem_evento},
                null, null, null , null, BdCulturama.data_evento);

        Event[] eventos = new Event[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_event);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_evento);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_evento);
        final int dataPos = resultados.getColumnIndex(BdCulturama.data_evento);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_evento);
       // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            eventos[pos] = new Event();

         //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            eventos[pos].setId(resultados.getInt(idPos));
            eventos[pos].setNome_evento(resultados.getString(nomePos));
            eventos[pos].setDescricao_evento(resultados.getString(descPos));
            eventos[pos].setData_evento(resultados.getString(dataPos));
            eventos[pos].setImagem_evento(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return eventos;
    }


    public long inserirFavorit (int idOrg, String idEvent) {
        ContentValues values = new ContentValues();
        values.put("id_usuario", idOrg);
        values.put("id_event", idEvent);
        values.put("favoritado", true);
        return banco.insert(BdCulturama.tab_favorite, null, values);

    }


    public Event[] obterMyEventos(String id) {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.rawQuery("SELECT * FROM " + BdCulturama.tab_evento + " WHERE "+BdCulturama.id_organizador+" = ?", new String[]{String.valueOf(id)});


        Event[] eventos = new Event[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_event);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_evento);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_evento);
        final int dataPos = resultados.getColumnIndex(BdCulturama.data_evento);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_evento);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            eventos[pos] = new Event();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            eventos[pos].setId(resultados.getInt(idPos));
            eventos[pos].setNome_evento(resultados.getString(nomePos));
            eventos[pos].setDescricao_evento(resultados.getString(descPos));
            eventos[pos].setData_evento(resultados.getString(dataPos));
            eventos[pos].setImagem_evento(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return eventos;
    }


    public Event[] obterTodosEventosCat(String cat) {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.rawQuery("SELECT * FROM " + BdCulturama.tab_evento + " WHERE "+BdCulturama.cat_evento+" = ?  ORDER BY "+ BdCulturama.data_evento, new String[]{String.valueOf(cat)});


        Event[] eventos = new Event[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_event);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_evento);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_evento);
        final int dataPos = resultados.getColumnIndex(BdCulturama.data_evento);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_evento);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            eventos[pos] = new Event();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            eventos[pos].setId(resultados.getInt(idPos));
            eventos[pos].setNome_evento(resultados.getString(nomePos));
            eventos[pos].setDescricao_evento(resultados.getString(descPos));
            eventos[pos].setData_evento(resultados.getString(dataPos));
            eventos[pos].setImagem_evento(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return eventos;
    }

    public Visit[] obterTodosVisitCat(String cat) {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.rawQuery("SELECT * FROM " + BdCulturama.tab_visit + " WHERE "+BdCulturama.categoria+" = ? ", new String[]{String.valueOf(cat)});


        Visit[] eventos = new Visit[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_local);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_local);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_local);
        final int dataPos = resultados.getColumnIndex(BdCulturama.email_local);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_lugar);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            eventos[pos] = new Visit();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            eventos[pos].setId(resultados.getInt(idPos));
            eventos[pos].setNome_local(resultados.getString(nomePos));
            eventos[pos].setDescricao_local(resultados.getString(descPos));
            eventos[pos].setEmail_local(resultados.getString(dataPos));
            eventos[pos].setImagem_lugar(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return eventos;
    }




    public Event[] obterCATEventos(String cat) {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.rawQuery("SELECT * FROM " + BdCulturama.tab_evento + " WHERE "+BdCulturama.cat_evento+" = ?", new String[]{String.valueOf(cat)});


        Event[] eventos = new Event[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_event);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_evento);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_evento);
        final int dataPos = resultados.getColumnIndex(BdCulturama.data_evento);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_evento);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            eventos[pos] = new Event();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            eventos[pos].setId(resultados.getInt(idPos));
            eventos[pos].setNome_evento(resultados.getString(nomePos));
            eventos[pos].setDescricao_evento(resultados.getString(descPos));
            eventos[pos].setData_evento(resultados.getString(dataPos));
            eventos[pos].setImagem_evento(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return eventos;
    }


    public Visit[] obterCATVisit(String cat) {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.rawQuery("SELECT * FROM " + BdCulturama.tab_visit + " WHERE "+BdCulturama.categoria+" = ?", new String[]{String.valueOf(cat)});

        Visit[] visitis = new Visit[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_local);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_local);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_local);
        final int emailPos = resultados.getColumnIndex(BdCulturama.email_local);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_lugar);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            visitis[pos] = new Visit();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            visitis[pos].setId(resultados.getInt(idPos));
            visitis[pos].setNome_local(resultados.getString(nomePos));
            visitis[pos].setDescricao_local(resultados.getString(descPos));
            visitis[pos].setEmail_local(resultados.getString(emailPos));
            visitis[pos].setImagem_lugar(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return visitis;
    }

    public long avaliar(int idUser, int Org, int valor){

        ContentValues value = new ContentValues();
        value.put("id_usuario", idUser);
        value.put("id_organizador", Org);
        value.put("valor_avaliacao",valor);

        return banco.insert(BdCulturama.tab_avaliaçao, null, value);


    }

    public long AlterAvaliaçao(int idUser, int Org, int valor){

        ContentValues value = new ContentValues();
        value.put("valor_avaliacao",valor);

        String[] args ={String.valueOf(idUser), String.valueOf(Org)};
        return banco.update(BdCulturama.tab_avaliaçao, value,"id_usuario=? and id_organizador=?", args);

    }









    public Visit[] obterVisit() {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.query(BdCulturama.tab_visit,
                new String[]{BdCulturama.id_local, BdCulturama.nome_local, BdCulturama.descricao_local,BdCulturama.email_local,BdCulturama.imagem_lugar},
                null, null, null, null, null);

        Visit[] visitis = new Visit[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_local);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_local);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_local);
        final int emailPos = resultados.getColumnIndex(BdCulturama.email_local);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_lugar);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos
        resultados.moveToFirst();
        while (!resultados.isAfterLast()) {
            visitis[pos] = new Visit();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            visitis[pos].setId(resultados.getInt(idPos));
            visitis[pos].setNome_local(resultados.getString(nomePos));
            visitis[pos].setDescricao_local(resultados.getString(descPos));
            visitis[pos].setEmail_local(resultados.getString(emailPos));
            visitis[pos].setImagem_lugar(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return visitis;
    }

    public Visit[] obterMyVisit(String id) {

        SQLiteDatabase db = conexao.getReadableDatabase();
        Cursor resultados = db.rawQuery("SELECT * FROM " + BdCulturama.tab_visit + " WHERE "+BdCulturama.id_organizador_local+" = ?", new String[]{String.valueOf(id)});

        Visit[] visitis = new Visit[resultados.getCount()];

        resultados.moveToFirst();

        // Para obter uma string, int, etc de uma coluna, é preciso do índice
        // Aqui os índices são salvos para não precisar procurar por eles
        // no Cursor. Só para otimizar mesmo.
        final int idPos = resultados.getColumnIndex(BdCulturama.id_local);
        final int nomePos = resultados.getColumnIndex(BdCulturama.nome_local);
        final int descPos = resultados.getColumnIndex(BdCulturama.descricao_local);
        final int emailPos = resultados.getColumnIndex(BdCulturama.email_local);
        final int imgPos = resultados.getColumnIndex(BdCulturama.imagem_lugar);
        // final byte[] img = resultados.getBlob(Byte.parseByte(BdCulturama.imagem_evento));


        int pos = 0; // posição atual na array de alunos

        while (!resultados.isAfterLast()) {
            visitis[pos] = new Visit();

            //   final Bitmap bt =  BitmapFactory.decodeByteArray(img, 0, img.length);
            visitis[pos].setId(resultados.getInt(idPos));
            visitis[pos].setNome_local(resultados.getString(nomePos));
            visitis[pos].setDescricao_local(resultados.getString(descPos));
            visitis[pos].setEmail_local(resultados.getString(emailPos));
            visitis[pos].setImagem_lugar(resultados.getBlob(Byte.parseByte(String.valueOf(imgPos))));


            resultados.moveToNext();
            pos++;
        }

        resultados.close();

        return visitis;
    }

}
