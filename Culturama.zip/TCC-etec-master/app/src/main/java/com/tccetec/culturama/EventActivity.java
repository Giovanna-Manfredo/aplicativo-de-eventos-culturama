package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.util.ArrayList;
import java.util.List;

public class EventActivity extends AppCompatActivity {
  CulturamaDAO dao;
    TextView textView;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView textView7;
    TextView textView8;
    TextView textView9;
    TextView textView10;

    String id;
    ImageView img;

    String namePut;
    String namePreco;
    String nameDesc;
    String nameLink;
    String nameData;
    String nameHoraE;
    String nameHoraS;
    String nameOrg;
    String nameEnd;
    String nameCat;
    Event e;
    Usuarios u;
    ImageButton imageB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        getSupportFragmentManager().beginTransaction().replace(R.id.frame, new detalhesFragment()).commit();
        img = findViewById(R.id.imageViewEvent);

        byte[] bt2 = getIntent().getByteArrayExtra("ImagemEvent");
        Bitmap bt = BitmapFactory.decodeByteArray(bt2,0,bt2.length);
        CulturamaDAO dao = new CulturamaDAO(this);
        img.setImageBitmap(bt);



        ImageButton b = findViewById(R.id.imageButton2);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fini(v);
            }
        });







        SharedPreferences preferences = getSharedPreferences("PREFERENCIA", 0);

        String id_e =  preferences.getString("id", null);




        e = new Event();
        e = dao.pegarEvent(id_e);

         u = new Usuarios();
        u = dao.selectId(e.getId_organizador());




    }

    private void fini(View v) {
        this.finish();
    }

    public void onCreateView1(View view) {

        Button mapa = findViewById(R.id.button6);

        mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              irmapa(v);
            }
        });

        final TextView tLink = findViewById(R.id.textLink);

        tLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getBaseContext().getSharedPreferences("local", 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("url", tLink.getText().toString() );
                editor.commit();
                startActivity(new Intent(getBaseContext(), WebActivity.class));
            }
        });

        SharedPreferences sp = getApplication().getSharedPreferences("ArquivoPreferencia", Context.MODE_PRIVATE);
        // String nome = sp.getString("nome","nao ");
        final int idOrg = sp.getInt("id",0);
        dao = new CulturamaDAO(this);

        final Usuarios tal = dao.selectId(idOrg);



        textView= view.findViewById(R.id.textNomeEvento);
        textView2= view.findViewById(R.id.textPreço);
        textView3= view.findViewById(R.id.textLink);
        textView4= view.findViewById(R.id.textDesc);
        textView5= view.findViewById(R.id.textData);
        textView6= view.findViewById(R.id.horEntre);
        textView7= view.findViewById(R.id.horaSai);
        textView8= view.findViewById(R.id.TextOrg);
        textView9= view.findViewById(R.id.textEndereco);
        textView10= view.findViewById(R.id.textCat);



        textView9.setText(e.getNum_endereco());



        textView6.setText("Entrada: "+ e.getHorario_entrada());
        textView7.setText("Saida: "+ e.getHorario_saida());
        textView10.setText("Categoria: "+ e.getCat_evento());




        textView8.setText("Organizador(a): "+ u.getNome());

        namePut = getIntent().getStringExtra("nameEvent");
        textView.setText(e.getNome_evento());

        namePreco = getIntent().getStringExtra("PreEvent");
        textView2.setText(e.getPreco_evento());



        nameDesc = getIntent().getStringExtra("DescEvent");
        textView4.setText(e.getDescricao_evento());

        nameLink = getIntent().getStringExtra("linkEvent");
        textView3.setText(e.getLink_evento());


        nameLink = getIntent().getStringExtra("DescEvent");
        textView4.setText(e.getDescricao_evento());

        nameLink = getIntent().getStringExtra("linkEvent");
        textView3.setText(e.getLink_evento());


        nameDesc = getIntent().getStringExtra("DescEvent");
        textView4.setText(e.getDescricao_evento());

        nameLink = getIntent().getStringExtra("linkEvent");
        textView3.setText(e.getLink_evento());



        nameDesc = getIntent().getStringExtra("DescEvent");
        textView4.setText(e.getDescricao_evento());

        nameLink = getIntent().getStringExtra("linkEvent");
        textView3.setText(e.getLink_evento());




    }

    public void irmapa(View v) {
        SharedPreferences preferences = getBaseContext().getSharedPreferences("local", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("loc",e.getNum_endereco() );
        editor.commit();
        startActivity(new Intent(getBaseContext(), MapsActivity.class));
    }

}