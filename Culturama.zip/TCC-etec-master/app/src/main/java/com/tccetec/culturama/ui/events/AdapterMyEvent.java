package com.tccetec.culturama.ui.events;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.EventActivity;
import com.tccetec.culturama.LoginActivity;
import com.tccetec.culturama.R;
import com.tccetec.culturama.editActivity;

import java.util.List;

public class AdapterMyEvent extends RecyclerView.Adapter<AdapterMyEvent.MyViewHolder> {
    Context context;
    List<Event> eventList;
    CulturamaDAO dao;

    public AdapterMyEvent(List<Event> eventos) {
        eventList = eventos;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if (context == null) {
            context = parent.getContext();
        }

        View view = LayoutInflater.from(context).inflate(R.layout.layout_event, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        holder.nameEvent.setText(eventList.get(position).getNome_evento());
        holder.DataEvent.setText(eventList.get(position).getData_evento());
        holder.imageEvent.setImageBitmap(eventList.get(position).getImagem_evento());

        holder.CardEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = context.getSharedPreferences("ARQUIVO_PREFERENCIA", 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("id", String.valueOf(eventList.get(position).getId()));
                editor.commit();
                dao = new CulturamaDAO(context);
                byte[] img = dao.recuperaImag(eventList.get(position).getId());
                Intent intent=new Intent(context, editActivity.class);
                intent.putExtra("idEvent",eventList.get(position).getId());
                intent.putExtra("nameEvent", eventList.get(position).getNome_evento());
                intent.putExtra("ImagemEvent", img);
                intent.putExtra("DescEvent", eventList.get(position).getDescricao_evento());
                intent.putExtra("DataEvent", eventList.get(position).getData_evento());
                intent.putExtra("HortaEntreEvent", eventList.get(position).getHorario_entrada());
                intent.putExtra("HoraSaidEvent", eventList.get(position).getHorario_saida());
                intent.putExtra("OrgEvent", eventList.get(position).getId_organizador());
                intent.putExtra("EndEvent", eventList.get(position).getNum_endereco());
                intent.putExtra("PreEvent", eventList.get(position).getPreco_evento());
                intent.putExtra("linkEvent", eventList.get(position).getLink_evento());

                v.getContext().startActivity(intent);


            }
        });

    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{

        private ImageView imageEvent;
        private TextView nameEvent;
        private TextView DescEvent;
        private TextView DataEvent;
        private CardView CardEvent;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageEvent = itemView.findViewById(R.id.imageEvent);
            nameEvent = itemView.findViewById(R.id.nameEvent);
            DataEvent = itemView.findViewById(R.id.DataEvent);
            CardEvent = itemView.findViewById(R.id.cardEvent);


        }
    }
}
