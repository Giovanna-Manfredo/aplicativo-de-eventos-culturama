package com.tccetec.culturama.ui.visit;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tccetec.culturama.AdapterCat;
import com.tccetec.culturama.AdapterCatVis;
import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.MenuActivity;
import com.tccetec.culturama.R;
import com.tccetec.culturama.ui.events.AdapterEvent;
import com.tccetec.culturama.ui.events.Event;

import java.util.ArrayList;
import java.util.List;

public class VisitFragment extends Fragment {
    CulturamaDAO dao;
   RecyclerView RecyCat;
    private Visit[] Visita = {new Visit(1,"MUSEU","Vei ser loko","01/02/333","sadasd","ssss",1,"tal","ssss","ssss","ssss",null)};



    private RecyclerView recyclerview;
    private List<Visit> visits = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_visit, container, false);
        recyclerview = view.findViewById(R.id.recyclerView2);
        RecyCat = view.findViewById(R.id.recycatv);
        List<String> categoria = new ArrayList<>();
        categoria.add("Outros");
        categoria.add("Culturais");
        categoria.add("Festas");
        categoria.add("Exposições");
        categoria.add("Empresariais");
        categoria.add("Educacionais e Acadêmicos");
        categoria.add("Esportes");
        categoria.add("Torneios");
        categoria.add("Parques");
        categoria.add("Ciência e Tecnologia");

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        RecyCat.setLayoutManager(layoutManager);
        AdapterCatVis adapter = new AdapterCatVis(categoria,view);
        RecyCat.setAdapter(adapter);

        initView(view);
        return view;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initVisit();
    }
    private void initView(View view) {
        ((MenuActivity) getActivity()).onFragmentViewCreatedVisi(view,visits); // Metodo que deve ser implementado na Activity


    }
    private void initVisit() {
        visits.clear();
        dao = new CulturamaDAO(getContext());
        Visit[]list = dao.obterVisit();

            for (int i = 0; i < list.length; i++) {

                visits.add(list[i]);
            }

        }
    }
