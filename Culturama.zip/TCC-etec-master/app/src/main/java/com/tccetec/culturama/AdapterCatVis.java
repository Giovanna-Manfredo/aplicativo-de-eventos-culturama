package com.tccetec.culturama;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.visit.Visit;

import java.util.ArrayList;
import java.util.List;

public class AdapterCatVis extends RecyclerView.Adapter<AdapterCatVis.MyViewHolder> {

    Context context;
    List<String> eventList;
    CulturamaDAO dao;
    View view;
    public AdapterCatVis(List<String> eventos,View cont) {
        eventList = eventos;
        view = cont;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (context == null) {
            context = parent.getContext();
        }

        View view = LayoutInflater.from(context).inflate(R.layout.layout_cat, parent, false);

        return new AdapterCatVis.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

       final  String nome= eventList.get(position);
         holder.nameCat.setText(nome);

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Visit[] e;
                List<Visit> eventos = new ArrayList<>();
                dao = new CulturamaDAO(context);
                e = dao.obterTodosVisitCat(holder.nameCat.getText().toString());

                for (int i = 0; i < e.length; i++) {

                    eventos.add(e[i]);
                }

                MenuActivity m = new MenuActivity();
                m.onFragmentViewCreatedVisi(view,eventos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{


        private TextView nameCat;
        private CardView card;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.cardCat);
           nameCat = itemView.findViewById(R.id.NameCategoria);


        }
    }

}
