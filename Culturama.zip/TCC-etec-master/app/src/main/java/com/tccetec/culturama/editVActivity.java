package com.tccetec.culturama;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.visit.Visit;

public class editVActivity extends AppCompatActivity {
    TextView textView;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView textView7;
    TextView textView8;
    Bitmap foto;
    CulturamaDAO dao;
    private static final int PICK_IMAGE_REQUEST = 100;
    String link ;
    String id;
    Bitmap bt;
    int idOrg;
    String id_e;
    ImageView objectImageView;
    private Uri imagePath ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_visit);


            Button btsai = findViewById(R.id.button5);


            btsai.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cancel(v);
                }
            });


        try {



        }catch (Exception e){
            Toast.makeText(this, "erro no find", Toast.LENGTH_SHORT).show();
        }

        SharedPreferences preferences = getSharedPreferences("ARQUIVO_PREFE", 0);

     id_e =  preferences.getString("id", null);



        SharedPreferences sp = getApplication().getSharedPreferences("ArquivoPreferencia", Context.MODE_PRIVATE);
        idOrg = sp.getInt("id",0);



        dao = new CulturamaDAO(this);
        Visit v = new Visit();


        Spinner spinner = findViewById(R.id.spinnerCat);
        ArrayAdapter<CharSequence> adapt = ArrayAdapter.createFromResource(this, R.array.Categorias, android.R.layout.simple_spinner_item);
        adapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapt);



        try {


            v = dao.pegarVisit(id_e);

            objectImageView = findViewById(R.id.imageViewEvent2);


        }catch (Exception e){
            Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
        }


        TextView t = this.findViewById(R.id.name);
        String ve = String.valueOf(v.getNome_local());
        t.setText(ve);


        textView2 = this.findViewById(R.id.editCont);
        String cat = v.getEmail_local();
        textView2.setText(cat);

        textView3 = this.findViewById(R.id.editDesc);
        String des = v.getDescricao_local();
        textView3.setText(des);

        textView4 = this.findViewById(R.id.editTele);
        String tele = v.getTelefone_local();
        textView4.setText(tele);

        textView5 = this.findViewById(R.id.editFunc);
        String locall = v.getFuncionamento_local();
        textView5.setText(locall);

        TextView vt =  this.findViewById(R.id.editEnd);
        vt.setText(v.getId_endereco());

        TextView v1 = this.findViewById(R.id.editPre);

        v1.setText(String.valueOf(v.getPreço()));

        TextView v2 = this.findViewById(R.id.editLink);

        v2.setText(String.valueOf(v.getLink()));






        foto = dao.recuFotoV(v.getId());
        objectImageView.setImageBitmap(foto);
        Button bt = this.findViewById(R.id.btnImage);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage(v);
            }
        });



    }

    private void cancel(View v) {
        this.finish();
    }

    public void Delet(View view){
        SharedPreferences preferences = getSharedPreferences("ARQUIVO_PREFE", 0);
        id_e =  preferences.getString("id", null);
        dao.deleteV(id_e);
        this.finish();
        Intent intent = new Intent(editVActivity.this, MenuActivity.class);
        startActivity(intent);

    }



    public void Altere(View view){
        if(bt == null){
            bt= foto;
        }

        TextView nomeText = this.findViewById(R.id.name);
        String nome = nomeText.getText().toString();

        TextView contText = this.findViewById(R.id.editCont);
        String email = contText.getText().toString();

        TextView descText = this.findViewById(R.id.editDesc);
        String desc = descText.getText().toString();

        TextView teleText = this.findViewById(R.id.editTele);
        String telefone = teleText.getText().toString();

        TextView funcText = this.findViewById(R.id.editFunc);
        String func = funcText.getText().toString();

        TextView endText = this.findViewById(R.id.editEnd);
        String ende = endText.getText().toString();

        TextView preText = this.findViewById(R.id.editPre);
        String prec = preText.getText().toString();

        TextView linkText = this.findViewById(R.id.editLink);
        String linkk = linkText.getText().toString();

        if (nome.trim().equals("") ||email.trim().equals("") || desc.trim().equals("") || telefone.trim().equals("") || func.trim().equals("") || ende.trim().equals("") ) {
            Toast.makeText(this, "Informações ou Foto Faltando", Toast.LENGTH_SHORT).show();

            Toast.makeText(this, "Falta informações", Toast.LENGTH_SHORT).show();

        } else {

            if (android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() == false) {

                Toast.makeText(this, "Email invalido", Toast.LENGTH_SHORT).show();


            }else {

                if(telefone.length()<12){
                    Toast.makeText(this, "Telefone com digitos  insuficientes", Toast.LENGTH_SHORT).show();
                }else {
                     Spinner editSpinner = findViewById(R.id.spinnerCat);
                    String s = editSpinner.getSelectedItem().toString();
                    dao.AlterarVisit(id_e, nome, email, desc, telefone, s, func, ende, bt, idOrg, prec, linkk);


                    Intent intent = new Intent(editVActivity.this, MenuActivity.class);
                    startActivity(intent);
                    this.finish();
                }
            }
        }

    }







    public void chooseImage(View objectView){
        try{

            Intent objectIntent = new Intent();
            objectIntent.setType("image/*");
            objectIntent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);
        }catch (Exception e){

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode ==RESULT_OK && data!=null && data.getData() !=null ){
                imagePath = data.getData();
                bt = MediaStore.Images.Media.getBitmap(getContentResolver(),imagePath);

                objectImageView.setImageBitmap(bt);
            }
        }catch (Exception e){

        }

    }
}