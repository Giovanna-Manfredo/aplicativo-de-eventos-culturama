package com.tccetec.culturama.ui.visit;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.Serializable;

public class Visit implements Serializable {

    private Integer id;
    private  String nome_local;
    private  String email_local ;
    private  String descricao_local ;
    private  String telefone_local;
    private  String funcionamento_local ;
    private  int id_organizador ;
    private  String id_endereco ;
    private  String preço ;
    private  String link ;
    private  String categoria ;
    private Bitmap imagem_lugar;

    public Visit() {
    }

    public Visit(Integer id, String nome_local, String email_local, String descricao_local, String telefone_local, String funcionamento_local, int id_organizador, String id_endereco, String preço, String link, String categoria, Bitmap imagem_lugar) {
        this.id = id;
        this.nome_local = nome_local;
        this.email_local = email_local;
        this.descricao_local = descricao_local;
        this.telefone_local = telefone_local;
        this.funcionamento_local = funcionamento_local;
        this.id_organizador = id_organizador;
        this.id_endereco = id_endereco;
        this.preço = preço;
        this.link = link;
        this.categoria = categoria;
        this.imagem_lugar = imagem_lugar;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome_local() {
        return nome_local;
    }

    public void setNome_local(String nome_local) {
        this.nome_local = nome_local;
    }

    public String getEmail_local() {
        return email_local;
    }

    public void setEmail_local(String email_local) {
        this.email_local = email_local;
    }

    public String getDescricao_local() {
        return descricao_local;
    }

    public void setDescricao_local(String descricao_local) {
        this.descricao_local = descricao_local;
    }

    public String getTelefone_local() {
        return telefone_local;
    }

    public void setTelefone_local(String telefone_local) {
        this.telefone_local = telefone_local;
    }

    public String getFuncionamento_local() {
        return funcionamento_local;
    }

    public void setFuncionamento_local(String funcionamento_local) {
        this.funcionamento_local = funcionamento_local;
    }

    public int getId_organizador() {
        return id_organizador;
    }

    public void setId_organizador(int id_organizador) {
        this.id_organizador = id_organizador;
    }

    public String getId_endereco() {
        return id_endereco;
    }

    public void setId_endereco(String id_endereco) {
        this.id_endereco = id_endereco;
    }

    public String getPreço() {
        return preço;
    }

    public void setPreço(String preço) {
        this.preço = preço;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Bitmap getImagem_lugar() {
        return imagem_lugar;
    }

    public void setImagem_lugar(Bitmap imagem_lugar) {

        this.imagem_lugar = imagem_lugar;
    }

    public void setImagem_lugar(byte[] imagem_lugar) {
        final Bitmap bt = BitmapFactory.decodeByteArray(imagem_lugar, 0, imagem_lugar.length);
        this.imagem_lugar = bt;
    }
}
