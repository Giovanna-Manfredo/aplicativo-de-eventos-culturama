package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.util.ArrayList;

public class RegisterActivityTres extends AppCompatActivity {
    private CulturamaDAO dao;
    private CheckBox termos;
    private Button voltar;
    private ImageButton imgB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_tres);
        termos = findViewById(R.id.Termos);
        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new TermosFragment()).commit();
        dao = new CulturamaDAO(this);
        voltar = findViewById(R.id.button3);
        imgB = findViewById(R.id.imageButton4);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                v(v);


            }
        });

        imgB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v(v);
            }
        });



    }

    private void v(View v) {
        this.finish();
    }


    public void registrar(View view) {
        if (termos.isChecked() == false) {

            Toast.makeText(this, "Aceite os termos de uso.", Toast.LENGTH_SHORT).show();
        } else {
            {


                Bundle extras = getIntent().getExtras();
                String nomePessoa = extras.getString("nome");
                String senha = extras.getString("senha");
                String email = extras.getString("email");
                String phone = extras.getString("phone");
                String dataNasc = extras.getString("dataNasc");
                byte[] img = extras.getByteArray("IMG");
                String[] categorias = extras.getStringArray("categorias");


                Bitmap bitmapImage = BitmapFactory.decodeByteArray(img, 0, img.length);


                Usuarios u = new Usuarios();
                u.setNome(nomePessoa);
                u.setSenha(senha);
                u.setEmail(email);
                u.setTelefone(phone);
                u.setDataNasc(dataNasc);
                u.setCategorias(categorias);
                u.setImagem_user(bitmapImage);


                try {


                    dao.inserir(u);



                    Intent intent=new Intent(getBaseContext(), LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);


                    this.finish();

                } catch (Exception e) {
                    Toast.makeText(this, "erro" + e, Toast.LENGTH_SHORT).show();
                }

            }
        }
    }
}