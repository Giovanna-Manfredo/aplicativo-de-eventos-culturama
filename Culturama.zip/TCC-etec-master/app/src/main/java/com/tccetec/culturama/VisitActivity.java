package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;
import com.tccetec.culturama.ui.visit.Visit;

public class VisitActivity extends AppCompatActivity {
    TextView textView;
    CulturamaDAO dao;
    String namePut;
    ImageView img;
    Visit v;

    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView textView7;
    TextView textView8;
    TextView textView9;
    TextView textView10;

    String id;



    String namePreco;
    String nameDesc;
    String nameLink;
    String nameData;
    String nameHoraE;
    String nameHoraS;
    String nameOrg;
    String nameEnd;
    String nameCat;
    Button mapa;

    Usuarios u;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit);
        getSupportFragmentManager().beginTransaction().replace(R.id.frame2, new DetalheVisitFragment()).commit();
        img = findViewById(R.id.imageViewVisit);





        byte[] bt2 = getIntent().getByteArrayExtra("ImagemVisit");
        Bitmap bt = BitmapFactory.decodeByteArray(bt2,0,bt2.length);
        dao = new CulturamaDAO(this);
        img.setImageBitmap(bt);


        ImageButton b = findViewById(R.id.imageButton2);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fini(v);
            }
        });

        dao = new CulturamaDAO(this);


        SharedPreferences preferences = getSharedPreferences("viiii", 0);

        String id_e =  preferences.getString("id", null);

        v = new Visit();
        v = dao.pegarVisit(id_e);



        u = new Usuarios();
        u = dao.selectId(v.getId_organizador());




    }

    private void fini(View v) {
        this.finish();
    }

    public void onCreateView1(View view) {
        final TextView tLink = findViewById(R.id.textLink);

        tLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getBaseContext().getSharedPreferences("local", 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("url", tLink.getText().toString() );
                editor.commit();
                startActivity(new Intent(getBaseContext(), WebActivity.class));
            }
        });
        textView= view.findViewById(R.id.textNomeEvento);
        textView2= view.findViewById(R.id.textPreço);
        textView3= view.findViewById(R.id.textLink);
        textView4= view.findViewById(R.id.textDesc);
        textView5= view.findViewById(R.id.TextEmail);
        textView6= view.findViewById(R.id.textTele);
        textView7= view.findViewById(R.id.func);
        textView8= view.findViewById(R.id.TextOrg);
        textView9= view.findViewById(R.id.textEndereco);
        textView10= view.findViewById(R.id.textCat);



        textView9.setText("Endereço: "+ v.getId_endereco());

        textView6.setText("Telefone: "+ v.getTelefone_local());
        textView7.setText("Funcionamento: "+ v.getFuncionamento_local());
        textView10.setText("Categoria: "+ v.getCategoria());




        textView8.setText("Organizador(a): "+ u.getNome());

        namePut = getIntent().getStringExtra("nameEvent");
        textView.setText(v.getNome_local());

        namePreco = getIntent().getStringExtra("PreEvent");
        textView2.setText(v.getPreço());



        nameDesc = getIntent().getStringExtra("DescEvent");
        textView4.setText(v.getDescricao_local());

        nameLink = getIntent().getStringExtra("linkEvent");
        textView3.setText(v.getLink());


        textView5.setText(v.getEmail_local());










    }

    public void irmapa(View v) {


        SharedPreferences preferences1 = getSharedPreferences("viiii", 0);

        String id_e =  preferences1.getString("id", null);

       Visit vi = new Visit();
        vi = dao.pegarVisit(id_e);

        SharedPreferences preferences = getBaseContext().getSharedPreferences("local", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("loc", vi.getId_endereco() );
        editor.commit();
        startActivity(new Intent(getBaseContext(), MapsActivity.class));
    }
}