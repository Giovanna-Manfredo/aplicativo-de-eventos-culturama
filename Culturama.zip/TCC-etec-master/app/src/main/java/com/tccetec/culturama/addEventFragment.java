package com.tccetec.culturama;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link addEventFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class addEventFragment extends Fragment {
    EditText editNome;
CulturamaDAO dao;
    TextView editEnde;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public addEventFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment addEventFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static addEventFragment newInstance(String param1, String param2) {
        addEventFragment fragment = new addEventFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);


        }




    }
    @Override
    public void onViewCreated (View view, Bundle savedInstanceState) {
        ((MenuActivity) getActivity()).onFragmentViewCreated2(view); // Metodo que deve ser implementado na Activity
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView = inflater.inflate(R.layout.fragment_add_event, container, false);



        Spinner spinner = rootView.findViewById(R.id.editCat);
        ArrayAdapter<CharSequence> adapt = ArrayAdapter.createFromResource(getContext(), R.array.Categorias, android.R.layout.simple_spinner_item);
        adapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapt);

        Button btn = rootView.findViewById(R.id.button7);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



        editNome = rootView.findViewById(R.id.editNome);
        TextView editPreco = rootView.findViewById(R.id.editPreco);
        editEnde = rootView.findViewById(R.id.editEnd);
        TextView editDes = rootView.findViewById(R.id.editDesc);
        TextView editSaida = rootView.findViewById(R.id.horaSair);
        TextView editEntrada = rootView.findViewById(R.id.horaEntre);
        TextView editData = rootView.findViewById(R.id.editData);
        Spinner editCat = rootView.findViewById(R.id.editCat);
        TextView editLink = rootView.findViewById(R.id.editLink);


        String nameEvent = editNome.getText().toString();
        String precoEvent = editPreco.getText().toString();
     final  String enderEvet = editEnde.getText().toString();
        String descriEvent = editDes.getText().toString();
        String saidaEvent = editSaida.getText().toString();
        String entraEvent = editEntrada.getText().toString();
        String dataEvent = editData.getText().toString();
        String catEvent = editCat.getSelectedItem().toString();
        String linkEvent = editLink.getText().toString();


        //validacoes


                Button btmap = rootView.findViewById(R.id.button8);

                btmap.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Vaipromapa(enderEvet);
                    }
                });


                SharedPreferences preferences = getActivity().getSharedPreferences("pre", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();

                if(nameEvent.trim().equals("")||dataEvent.trim().equals("")||enderEvet.trim().equals("")|| descriEvent.trim().equals("")||saidaEvent.trim().equals("")||entraEvent.trim().equals("")){
                    Toast.makeText(getContext(), "Informações ou Foto Faltando", Toast.LENGTH_SHORT).show();
                }else{

                  editor.putString("nameEvent", nameEvent);
                  editor.putString("precoEvent", precoEvent );
                  editor.putString("enderEvet", enderEvet);
                  editor.putString("descriEvent", descriEvent);



                  editor.putString("catEvent", catEvent);


                    String dataDigitadaStr = dataEvent; // Ex: "04/05/2010"


                    SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
                    Date dataDigitada = null;
                    try {
                        dataDigitada= formater.parse(dataDigitadaStr);

                        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        assert dataDigitada != null;
                        String data = dateFormat.format(dataDigitada);

                        if (!dataDigitadaStr.equals(data)) {

                            Toast.makeText(getContext(), "Data inválida", Toast.LENGTH_SHORT).show();
                            Log.d("data",data);
                            Log.d("data",dataDigitadaStr);


                        }else{

                            if(hora(saidaEvent) == true) {
                                editor.putString("saidaEvent", saidaEvent);

                                if(hora(entraEvent) == true) {


                                    Date hoje = new Date();
                                    if(dataDigitada.getTime() <= hoje.getTime()){
                                        Toast.makeText(getContext(), "A data é menor que a data atual", Toast.LENGTH_SHORT).show();

                                    }else {

                                        editor.putString("entraEvent", entraEvent);

                                        editor.putString("dataEvent", dataEvent);

                                        editor.putString("linkEvent", linkEvent);
                                        editor.apply();


                                        ((MenuActivity) getActivity()).registerEvent(rootView);
                                    }

                                }else {
                                    Toast.makeText(getContext(), "Horario de Entrada inválido", Toast.LENGTH_SHORT).show();
                                }
                            }else{
                                Toast.makeText(getContext(), "Horario de saída inválido", Toast.LENGTH_SHORT).show();
                            }




                        }




                    } catch (ParseException e) {
                        Toast.makeText(getContext(), "Data inválida", Toast.LENGTH_SHORT).show();
                    }



                }

            }
        });


        {

    }




        return rootView;
    }

    private void Vaipromapa(String enderEvet) {
        SharedPreferences preferences = getContext().getSharedPreferences("local", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("loc", enderEvet );
        editor.commit();
        startActivity(new Intent(getContext(), MapsActivity.class));
    }

    public  boolean  hora(String args) {

        if( args.length()<5) {
            return false;
        }else {
            String hora = args;

            // separa a hora o minuto e segundo em um array
            String[] hms = hora.split(":");

            int horas = Integer.parseInt(hms[0]);
            int minutos = Integer.parseInt(hms[1]);


            if (horas > 23) {

                return false;
            }else{

                if(minutos > 59){
                    return false;
                }else{
                    return true;
                }


            }

        }

        }


        public  void Abramap(View view){
            SharedPreferences preferences = getContext().getSharedPreferences("local", 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("loc", editEnde.getText().toString() );
            editor.commit();
            startActivity(new Intent(getContext(), MapsActivity.class));
        }
    }

