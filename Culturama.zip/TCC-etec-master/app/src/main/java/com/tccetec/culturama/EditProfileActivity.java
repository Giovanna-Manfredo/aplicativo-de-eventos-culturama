package com.tccetec.culturama;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.events.AdapterMyEvent;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EditProfileActivity extends AppCompatActivity {
    TextView textView;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView textView7;
    TextView textView8;
    CulturamaDAO dao;
    private static final int PICK_IMAGE_REQUEST = 100;
    String link ;
    String id;
    Bitmap bt;
    int idOrg;
   String nome;
    Bitmap fotoUser;
    ImageView objectImageView;
    private Uri imagePath ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        try {
            objectImageView = findViewById(R.id.imageView);
        }catch (Exception e){
            Toast.makeText(this, "erro no find", Toast.LENGTH_SHORT).show();
        }
        SharedPreferences sp = getApplication().getSharedPreferences("ArquivoPreferencia", Context.MODE_PRIVATE);
      // String nome = sp.getString("nome","nao ");
        idOrg = sp.getInt("id",0);
        dao = new CulturamaDAO(this);
        Usuarios tal = dao.selectId(idOrg);
         nome = tal.getNome();
        String senha = tal.getSenha();
        String email = tal.getEmail();
        String end = tal.getEndereco();
        String tele = tal.getTelefone();
        String data = tal.getDataNasc();
        String[] lista = tal.getCategorias();

        fotoUser = dao.recuperaPerfil(idOrg);




        ImageView fotoPerfil = findViewById(R.id.imageView);
        fotoPerfil.setImageBitmap(fotoUser);



        textView = findViewById(R.id.PersonName);
        textView.setText(nome);

        textView = findViewById(R.id.PersonSenha);
        textView.setText(senha);

        textView = findViewById(R.id.PersonEmail);
        textView.setText(email);

        textView = findViewById(R.id.PersonTele);
        textView.setText(tele);

        textView = findViewById(R.id.personNasc);
        textView.setText(data);

        textView = findViewById(R.id.personEnd);
        textView.setText(end);




        Button bt = this.findViewById(R.id.button2);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage(v);
            }
        });


        Button al = this.findViewById(R.id.button10);

        al.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Altere(v);
            }
        });


    }
    private boolean validateEmailFormat(final String email) {
        if (android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return true;
        }
        return false;
    }


    public void Altere(View view){



        TextView linkText = this.findViewById(R.id.PersonName);
       String nomeP = linkText.getText().toString();

        TextView nomeText = this.findViewById(R.id.PersonEmail);
        String emailP = nomeText.getText().toString();

        TextView descText = this.findViewById(R.id.PersonSenha);
        String senhaP = descText.getText().toString();

        TextView dataText = this.findViewById(R.id.personEnd);
        String endP = dataText.getText().toString();


        TextView horaEntre = this.findViewById(R.id.PersonTele);
        String teleP = horaEntre.getText().toString();

        TextView horaSai = this.findViewById(R.id.personNasc);
        String nascP = horaSai.getText().toString();

        if(bt == null){
            bt = fotoUser;
        }


        if(nomeP.trim().equals("")||senhaP.trim().equals("")||emailP.trim().equals("")||teleP.trim().equals("")||nascP.trim().equals("")){
            Toast.makeText(EditProfileActivity.this, "Informações ou Foto Faltando", Toast.LENGTH_SHORT).show();
        }else{
            cad(emailP,nomeP,senhaP,teleP,nascP,endP);
        }


//        if(bt == null){
//             bt = fotoUser;
//        }
//
//
//        try {
//            long idd = dao.AlterarUser(String.valueOf(idOrg), nomeP, emailP,senhaP,endP,teleP,nascP,bt);
//            Toast.makeText(this, "" + idd, Toast.LENGTH_SHORT).show();
//            this.finish();
//
//        }catch (Exception e){
//            Toast.makeText(this, ""+ e, Toast.LENGTH_SHORT).show();
//        }
////
//  Intent intent = new Intent(EditProfileActivity.this, MenuActivity.class);
//  startActivity(intent);

    }

    private void cad(String emailP, String nomeP, String senhaP, String teleP, String nascP, String endP) {

        Boolean emailvalid = validateEmailFormat(emailP);
        Intent i = new Intent(getApplicationContext(), RegisterActivityDois.class);
        Bundle bd = new Bundle();
        bd.putString("nome", nomeP);
        if(emailvalid == true){
            bd.putString("email",emailP);

            if( senhaP.length()<8){
                Toast.makeText(this, "A senha precisa ter mais de 8 digitos", Toast.LENGTH_LONG).show();


            }else{
                bd.putString("senha", senhaP);
                if( teleP.length()<13){
                    Toast.makeText(this, "Telefone com digitos insuficientes", Toast.LENGTH_LONG).show();

                }else{
                    bd.putString("phone", teleP);


                    String dataDigitadaStr = nascP; // Ex: "04/05/2010"


                    SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
                    Date dataDigitada = null;
                    try {
                        dataDigitada= formater.parse(dataDigitadaStr);

                        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        assert dataDigitada != null;
                        String data = dateFormat.format(dataDigitada);

                        if (!dataDigitadaStr.equals(data)) {

                            Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
                            Log.d("data",data);
                            Log.d("data",dataDigitadaStr);
                        }else{

                            if(endP == null){

                                Toast.makeText(this, "Endereço vazio", Toast.LENGTH_SHORT).show();

                            }else {

                                finalizarCad(dataDigitada, bd, i, emailP, nomeP, senhaP, teleP, nascP,endP);

                            }
                        }




                    } catch (ParseException e) {
                        Toast.makeText(this, "Data invalida", Toast.LENGTH_SHORT).show();
                    }


                }

            }

        }else{
            Toast.makeText(this, "email invalido", Toast.LENGTH_SHORT).show();
        }




    }


    public void finalizarCad(Date dataDigitada, Bundle bd, Intent i, String emailP, String nomeP, String senhaP, String teleP, String nascP,String endP){

        Date hoje = new Date();

        if(dataDigitada.getTime() >= hoje.getTime()){
            Toast.makeText(this, "Data digitada maior que a data atual", Toast.LENGTH_SHORT).show();

        }else{
            try {
             dao.AlterarUser(String.valueOf(idOrg), nomeP, emailP,senhaP,endP,teleP,nascP,bt);

            this.finish();

        }catch (Exception e){
            Toast.makeText(this, ""+ e, Toast.LENGTH_SHORT).show();
        }
//
  Intent intent = new Intent(EditProfileActivity.this, MenuActivity.class);
  startActivity(intent);

            }




    }

    public void chooseImage(View objectView){
        try{

            Intent objectIntent = new Intent();
            objectIntent.setType("image/*");
            objectIntent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);
        }catch (Exception e){

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode ==RESULT_OK && data!=null && data.getData() !=null ){
                imagePath = data.getData();
                bt = MediaStore.Images.Media.getBitmap(getContentResolver(),imagePath);

                objectImageView.setImageBitmap(bt);
            }
        }catch (Exception e){

        }

    }
}