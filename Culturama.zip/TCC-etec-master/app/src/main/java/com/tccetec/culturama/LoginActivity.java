package com.tccetec.culturama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.usuarios.Usuarios;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    private EditText email;
    private EditText senha;
    private Button logar;
    private CulturamaDAO dao;
    private ArrayList<Usuarios> usuario;
    private ArrayList<Usuarios> usuarioFiltrado = new ArrayList<>();
    private static String ARQUIVO_PREFERENCIA = "ArquivoPreferencia";
    Usuarios userInfo;
    CheckBox conect ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dao = new CulturamaDAO(getBaseContext());
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
        logar = findViewById(R.id.Logar);
        conect = findViewById(R.id.checkBox);
        conect.setChecked(false);
        TextView cad = findViewById(R.id.textView29);
        SharedPreferences s = econectado();
        if(s.getString("nome", null) != null){
            email.setText(s.getString("nome", null));
            senha.setText(s.getString("senha", null));
            conect.setChecked(true);
            logar();

        }else{

        }


        cad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                finishe(v);

            }
        });
        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    logar();

                }
        });







    }

    private void econectado(String u, String s) {
        SharedPreferences preferences = getSharedPreferences("Conect", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("nome", u);
        editor.putString("senha", s);
        editor.commit();

    }

    public SharedPreferences econectado(){
        SharedPreferences sp = getApplication().getSharedPreferences("Conect", Context.MODE_PRIVATE);
        if(sp == null) {
         return null;

        }

        return sp;
    }



    public void logar(){
        String emailLog = email.getText().toString();
        String senhaLog = senha.getText().toString();



        try {

            Boolean user = dao.logar(emailLog, senhaLog);

            if(user == true){

                userInfo = new Usuarios();
                userInfo = dao.selectU(emailLog,senhaLog);

                if(conect.isChecked()==true){

                    econectado(emailLog,senhaLog);
                }else{
                    econectado(null,null);
                }



                SharedPreferences preferences = getSharedPreferences(ARQUIVO_PREFERENCIA, 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putInt("id", userInfo.getId());
                editor.putString("nome", userInfo.getNome());
                editor.putString("senha", userInfo.getSenha());
                editor.putString("email", userInfo.getEmail());
                editor.putString("telefone", userInfo.getTelefone());
                editor.putString("dataNasc", userInfo.getDataNasc());
                editor.putString("IMGU", String.valueOf(userInfo.getImagem_user()));



                editor.commit();

                Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                startActivity(intent);

            }else{
                Toast.makeText(LoginActivity.this, "Usuario ou senha incorretos!" , Toast.LENGTH_SHORT).show();
            }



        }catch (Exception e){
            Toast.makeText(LoginActivity.this, "Erro ao se logar" + e, Toast.LENGTH_SHORT).show();
        }

    }

    private void finishe(View v) {
        this.finish();
    }


}