package com.tccetec.culturama;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.tccetec.culturama.BD.CulturamaDAO;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link addEventFragment2#newInstance} factory method to
 * create an instance of this fragment.
 */
public class addEventFragment2 extends Fragment {
    EditText editNome;
CulturamaDAO dao;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public addEventFragment2() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment addEventFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static addEventFragment2 newInstance(String param1, String param2) {
        addEventFragment2 fragment = new addEventFragment2();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);


        }




    }
    @Override
    public void onViewCreated (View view, Bundle savedInstanceState) {
        ((MenuActivity) getActivity()).onFragmentViewCreated3(view); // Metodo que deve ser implementado na Activity
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView = inflater.inflate(R.layout.fragment_add_event2, container, false);


        Spinner spinner = rootView.findViewById(R.id.spinnerCatLocal);
        ArrayAdapter<CharSequence> adapt = ArrayAdapter.createFromResource(getContext(), R.array.Categorias, android.R.layout.simple_spinner_item);
        adapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapt);

        Button btn = rootView.findViewById(R.id.btnAddVisit);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                editNome = rootView.findViewById(R.id.NomeLocal);
                TextView editPreco = rootView.findViewById(R.id.editPrecoLoc);
                TextView editEmail = rootView.findViewById(R.id.editEmailLocal);
                TextView editDes = rootView.findViewById(R.id.descLocal);
                TextView editTele = rootView.findViewById(R.id.teleLocal);
                TextView editFunc = rootView.findViewById(R.id.funcioLocal);
                TextView editEnde = rootView.findViewById(R.id.editEnderecoLocal);
                TextView editLinkLo = rootView.findViewById(R.id.editLinkLocal);
                Spinner sp = rootView.findViewById(R.id.spinnerCatLocal);

                String editNomeu = editNome.getText().toString();
                String editPrecou = editPreco.getText().toString();
                String editEmailu = editEmail.getText().toString();
                String editDesu = editDes.getText().toString();
                String editTeleu = editTele.getText().toString();
                String editFuncu = editFunc.getText().toString();
                String editEndeu = editEnde.getText().toString();
                String editLinkLou = editLinkLo.getText().toString();
                String editSpinner = sp.getSelectedItem().toString();
                String cat = sp.getSelectedItem().toString();

                if (editNomeu.trim().equals("") ||editEmailu.trim().equals("") || editDesu.trim().equals("") || editTeleu.trim().equals("") || editFuncu.trim().equals("") || editEndeu.trim().equals("") ||  editSpinner.trim().equals("")) {
                    Toast.makeText(getContext(), "Informações ou Foto Faltando", Toast.LENGTH_SHORT).show();


                } else {
                    SharedPreferences preferences = getActivity().getSharedPreferences("prefVisit", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("nomeV", editNome.getText().toString());
                    if (android.util.Patterns.EMAIL_ADDRESS.matcher(editEmailu).matches() == false) {

                        Toast.makeText(getContext(), "Email inválido", Toast.LENGTH_SHORT).show();


                    }else {

                        if(editTele.length()<12){
                            Toast.makeText(getContext(), "Telefone com dígitos insuficientes", Toast.LENGTH_SHORT).show();
                        }else {

                            editor.putString("nomeV", editNome.getText().toString());
                            editor.putString("precoV", editPreco.getText().toString());
                            editor.putString("emailV", editEmail.getText().toString());
                            editor.putString("desV", editDes.getText().toString());
                            editor.putString("teleV", editTele.getText().toString());
                            editor.putString("FuncV", editFunc.getText().toString());
                            editor.putString("endeV", editEnde.getText().toString());
                            editor.putString("linkV", editLinkLo.getText().toString());
                            editor.putString("cat", cat);
                            editor.apply();


                            ((MenuActivity) getActivity()).registerLocal(rootView);
                        }
                    }
                }

            }
        });


        {

        }


        return rootView;



}


}