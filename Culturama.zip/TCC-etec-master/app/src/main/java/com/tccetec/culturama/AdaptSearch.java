package com.tccetec.culturama;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.tccetec.culturama.BD.CulturamaDAO;
import com.tccetec.culturama.ui.ModelItem;
import com.tccetec.culturama.ui.events.Event;
import com.tccetec.culturama.ui.usuarios.Usuarios;
import com.tccetec.culturama.ui.visit.Visit;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class AdaptSearch extends BaseAdapter {
    Event e;
    Visit vi;
    Context mContext;
    LayoutInflater inflater;
    List<ModelItem> modelList;
    ArrayList<ModelItem> ArrayList;
    CulturamaDAO dao;

    public AdaptSearch(Context context, List<ModelItem> arrayList) {
        mContext = context;
        this.modelList = arrayList;
        inflater = LayoutInflater.from(mContext);
        this.ArrayList = new ArrayList<>();
        this.ArrayList.addAll(modelList);
    }

    public class ViewHolder{
        TextView nome,org;
        ImageView EV;

        CardView card;
    }

    @Override
    public int getCount() {
        return modelList.size();
    }

    @Override
    public Object getItem(int position) {
        return modelList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView( final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.layout_item,null);
            holder.card = convertView.findViewById(R.id.cardEV);
            holder.nome = convertView.findViewById(R.id.NameS);
            holder.org = convertView.findViewById(R.id.OrgS);
            holder.EV = convertView.findViewById(R.id.imageS);

            convertView.setTag(holder);
        }else{
            holder = (ViewHolder)convertView.getTag();
        }

        Usuarios u = new Usuarios();
        dao = new CulturamaDAO(mContext);
        u = dao.pegaUserName(modelList.get(position).getOrgEV());
        holder.nome.setText(String.valueOf(modelList.get(position).getNome()));
        holder.org.setText(String.valueOf(u.getNome()));
        holder.EV.setImageBitmap(modelList.get(position).getImagem());

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String org = String.valueOf(modelList.get(position).getOrgEV());
                String nome = String.valueOf(modelList.get(position).getNome());
                String id = String.valueOf(modelList.get(position).getIdEV());
                Bitmap EV = modelList.get(position).getImagem();

                e = new Event();
                vi = new Visit();
                dao = new CulturamaDAO(mContext);

                 e = dao.pegarEvent(id);
                 if(modelList.get(position).iseEvent() == true) {

                     SharedPreferences preferences = mContext.getSharedPreferences("PREFERENCIA", 0);
                     SharedPreferences.Editor editor = preferences.edit();
                     editor.putString("id", String.valueOf(e.getId()));
                     editor.commit();

                     dao = new CulturamaDAO(mContext);
                     byte[] img = dao.recuperaImag(modelList.get(position).getIdEV());


                     Intent intent=new Intent(mContext, EventActivity.class);

                     intent.putExtra("ImagemEvent", img);

                     v.getContext().startActivity(intent);

                 }else{

                    vi = dao.pegarVisit(id);

                     SharedPreferences preferences = mContext.getSharedPreferences("viiii", 0);
                     SharedPreferences.Editor editor = preferences.edit();
                     editor.putString("id", String.valueOf(vi.getId()));
                     editor.commit();

                     dao = new CulturamaDAO(mContext);
                     byte[] img = dao.recuperaImagV(modelList.get(position).getIdEV());


                     Intent intent=new Intent(mContext, VisitActivity.class);

                     intent.putExtra("ImagemVisit", img);

                     v.getContext().startActivity(intent);


                 }


//                SharedPreferences preferences = mContext.getSharedPreferences("PREFERENCIA", 0);
//                SharedPreferences.Editor editor = preferences.edit();
//                editor.putString("id", String.valueOf(e.getId()));
//                editor.commit();
//
//                Intent intent = new Intent(mContext, EventActivity.class);
//
//                v.getContext().startActivity(intent);


            }});




        return convertView;
    }


    public void filter(String charText){
        charText = charText.toLowerCase(Locale.getDefault());
        modelList.clear();
        if(charText.length()==0){
            modelList.addAll(ArrayList);
        }else{
            for(ModelItem model: ArrayList ){
                if(model.getNome().toLowerCase(Locale.getDefault())
                    .contains(charText)){
                    modelList.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }

}
